#!/usr/bin/env bash
# Contact sheet of a video for exact recreations (RECREATE.md): 16 frames from <start> every <step> s, timestamp on each tile.
# Usage: bash tools/frame-sheet.sh <video> <start> <step> <out.jpg> [cols=4] [width=480]
v="$1"; s="${2:-0}"; st="${3:-0.1}"; out="$4"; cols="${5:-4}"; w="${6:-480}"
[ -f "$v" ] && [ -n "$out" ] || { echo "usage: frame-sheet.sh <video> <start> <step> <out.jpg> [cols] [width]"; exit 1; }
n=$((cols * cols))
fps=$(python -c "print(1/$st)")
ffmpeg -y -loglevel error -ss "$s" -i "$v" -frames:v "$n" \
  -vf "fps=$fps,scale=$w:-2,drawtext=text='%{pts\:hms\:$s}':x=6:y=6:fontsize=18:fontcolor=magenta:box=1:boxcolor=black@0.4,tile=${cols}x${cols}" \
  -frames:v 1 "$out" && echo "$out"
