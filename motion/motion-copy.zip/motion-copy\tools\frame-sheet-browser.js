// Contact sheet of an Instagram reel without downloading it (RECREATE.md, step 1).
// Open https://www.instagram.com/reel/<id>/embed/ in the built-in browser, click Play, then run this with javascript_tool,
// then `await sheet(start, step, count, cols)` and take a screenshot. The video is cross-origin, so the canvas can be shown
// but not read: the screenshot is the only output, and nothing is saved.
const v = document.querySelector("video");
v.pause(); v.muted = true;
window.sheet = async (t0, step, n, cols) => {
  let c = document.getElementById("sheet");
  if (!c) {
    c = document.createElement("canvas"); c.id = "sheet";
    Object.assign(c.style, { position: "fixed", left: "0", top: "0", zIndex: "100000", background: "#000" });
    document.body.appendChild(c);
  }
  const W = innerWidth, rows = Math.ceil(n / cols), tw = Math.floor(W / cols), th = Math.round(tw * v.videoHeight / v.videoWidth);
  c.width = W; c.height = rows * th; c.style.width = W + "px"; c.style.height = rows * th + "px";
  const g = c.getContext("2d"); g.font = "bold 13px sans-serif";
  for (let i = 0; i < n; i++) {
    const t = t0 + i * step; v.currentTime = t;
    await new Promise((r) => v.addEventListener("seeked", r, { once: true }));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    const x = (i % cols) * tw, y = Math.floor(i / cols) * th;
    g.drawImage(v, x, y, tw - 2, th - 2);
    g.fillStyle = "#f0f"; g.fillText(t.toFixed(2), x + 4, y + 14);
  }
  return { size: v.videoWidth + "x" + v.videoHeight, duration: v.duration };
};
