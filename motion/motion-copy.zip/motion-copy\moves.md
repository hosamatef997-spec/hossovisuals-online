# The moves (GSAP inside a HyperFrames page)

`tl` is the one paused timeline. Times are in seconds.

## Whip with motion blur (directional, no hard box edges)
```html
<svg width="0" height="0" style="position:absolute">
  <filter id="mb" x="-60%" y="-30%" width="220%" height="160%"><feGaussianBlur id="mb-g" stdDeviation="0 0" /></filter>
</svg>
<div id="name" style="filter:url(#mb)">YOUR NAME</div>
```
```js
tl.fromTo("#name", { x: -1900 }, { x: 0, duration: 0.24, ease: "expo.out" }, 4.38);
tl.fromTo("#mb-g", { attr: { stdDeviation: "90 0" } }, { attr: { stdDeviation: "0 0" }, duration: 0.26, ease: "power2.out" }, 4.38);
```
Keep the filter region wide (x -60%, width 220%), or the blur gets cut into a box.

## Text that inverts over the silhouette
```css
.dif { mix-blend-mode: difference; color: #fff; } /* dark over light, light over dark */
```
Put `.dif` on the moving element itself. A parent with a transform, opacity or filter isolates the blend, and the text then turns flat white.
For a part that must stay one solid colour (an accent slash or dot), use a second layer at the same position. Its letters are `color: transparent` and only the accent part shows.

## Letters falling one by one
```js
[...document.querySelectorAll("#name span")].forEach((el, i) =>
  tl.to(el, { y: 820, rotation: i % 2 ? 24 : -20, duration: 0.36, ease: "power2.in" }, 5.8 + i * 0.04));
```
Each letter is an inline-block `<span>`.

## Toggle → knob blooms into the next scene
```js
tl.to("#knob", { scale: 0.92, duration: 0.05 }, 9.4);                                   // press
tl.to("#knob", { x: 320, duration: 0.17, ease: "power3.inOut" }, 9.45);                 // slide
tl.to("#knob", { scaleX: 1.25, scaleY: 0.9, duration: 0.085 }, 9.45);                   // squash
tl.to("#knob", { scaleX: 1, scaleY: 1, duration: 0.12 }, 9.535);
tl.to("#knob", { scale: 10.5, duration: 0.25, ease: "power2.in" }, 10.15);              // bloom to fill the frame
```

## Word scramble before it lands
```js
tl.set("#word", { textContent: "K#V%A &ZQ" }, 10.5);
tl.set("#word", { textContent: "Brand &ZQ" }, 10.54);
tl.set("#word", { textContent: "Brand Films" }, 10.58);
```
Write the scrambles out in advance; no `Math.random()` while it plays.

## Pen trace with points
- An SVG `<path pathLength="1000" stroke-dasharray="1000">`, tweened `strokeDashoffset` 1000 → 0.
- Small `<rect>` points fade in at the time the line reaches them, and the pen cursor `set`s to each point in turn.
- Draw the outline in two strokes, like the reference: one side first, then the other.

## Typing with live guides
- Letters start `display:none` and are switched on one by one with `tl.set`.
- Dashed guide lines and a "### px" label sit inside the same inline-block as the letters, so they follow the width.
- Then a marquee (scale from the top-left corner) and the selection frame with handles snaps in.

---

# Pro moves (added 2026-11-02, from the 4K remakes)

## Real-time motion blur and 4K
- On the root: `data-motion-blur="on" data-motion-blur-shutter="220"`. Render with `--resolution portrait-4k` (or `landscape-4k`) at `--fps 60`.
- Put `data-motion-blur="off"` on anything that spins, zooms or turns in 3D. Otherwise the blur capture draws hard boxes around it.

## Rotate and scale inside HTML layers
GSAP transforms on nested SVG `<g>` elements drift off centre. Wrap each moving SVG piece in its own full-frame div and animate the div:
```html
<div id="ring" style="position:absolute;inset:0;transform-origin:540px 958px" data-motion-blur="off"><svg …>…</svg></div>
```
```js
tl.fromTo("#ring", { rotation: -30 }, { rotation: 150, duration: 2.7, ease: "none" }, 2.3);
```

## Morph circle → squircle → star (no plugin)
Build every shape from the same 4 cubic segments, so GSAP can tween `attr: { d }` straight between them:
```js
const circle = (r, k = 0.5523) => `M 0 ${-r} C ${r*k} ${-r} ${r} ${-r*k} ${r} 0 C ${r} ${r*k} ${r*k} ${r} 0 ${r} C ${-r*k} ${r} ${-r} ${r*k} ${-r} 0 C ${-r} ${-r*k} ${-r*k} ${-r} 0 ${-r} Z`;
const star = (r) => `M 0 ${-r} C ${r*.12} ${-r*.2} ${r*.2} ${-r*.12} ${r} 0 C ${r*.2} ${r*.12} ${r*.12} ${r*.2} 0 ${r} C ${-r*.12} ${r*.2} ${-r*.2} ${r*.12} ${-r} 0 C ${-r*.2} ${-r*.12} ${-r*.12} ${-r*.2} 0 ${-r} Z`;
tl.to("#ring path", { attr: { d: star(300) }, duration: 0.25, ease: "power2.out" }, 4.12);
```

## The camera rides a dot that draws a dotted line between cards
- The cards and lines live in one big "world" div. The camera moves by tweening the world's `x`/`y`, so the cards come into frame one after another.
- The visible line is dotted (`stroke-dasharray="2 8"`) and is revealed by a solid mask path's `strokeDashoffset`.
- The dot follows the tip of the line using `getPointAtLength` in an `onUpdate` (deterministic).
```js
const ride = (id, t0, d) => { const p = { v: 0 };
  tl.fromTo("#" + id, { strokeDashoffset: 1000 }, { strokeDashoffset: 0, duration: d, ease: "power1.inOut" }, t0);
  tl.to(p, { v: 1, duration: d, ease: "power1.inOut", onUpdate: () => { const el = document.getElementById(id), pt = el.getPointAtLength(p.v * el.getTotalLength()); dot.setAttribute("cx", pt.x); dot.setAttribute("cy", pt.y); } }, t0); };
tl.to("#world", { x: 540 - 1480, y: 958 - 1520, duration: 0.8, ease: "power2.inOut" }, 17.35);
```

## Liquid fill of a card
Lay a gradient over the card and reveal it with `clip-path: inset(0 0 0 100%)` → `inset(0 0 0 0%)` in about 0.18 s. Fade it out about 0.3 s later. For RTL text, reveal from right to left.

## Blobs that write the text, then wipe it
Three blurred circles (`filter: blur(46px); mix-blend-mode: screen`) sweep across the line. The text's `clip-path` inset follows the blobs: the left inset goes 100% → 0% for Arabic. On the way back, the right inset goes 0% → 100% and wipes it. Then the blobs gather and burst outward, and the logo appears with a soft flash.

## Real glass (frosted, iridescent rim)
```css
.glass { background: linear-gradient(160deg, rgba(255,255,255,.20), rgba(255,255,255,.05) 46%, rgba(255,255,255,.12));
  backdrop-filter: blur(26px) saturate(170%);
  box-shadow: inset 0 2px 0 rgba(255,255,255,.55), inset 16px 18px 40px rgba(255,236,210,.10), inset -18px -24px 50px rgba(255,160,80,.14), 0 40px 110px rgba(0,0,0,.55); }
.glass .rim { position:absolute; inset:0; border-radius:inherit; padding:2.5px;
  background: conic-gradient(from 210deg, #fff6e4f2, #f2b65440, #ff804ed9, #aabeff8c, #fff6e4e6, #f2b65433, #fff6e4f2);
  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; }
.glass .sheen { position:absolute; inset:0; border-radius:inherit; background: linear-gradient(118deg, transparent 28%, rgba(255,255,255,.16) 42%, transparent 56%); }
```
Put a glow behind the glass, or the blur shows nothing. Fill the UI with real things: a photo avatar in a conic-gradient ring, app icons with labels, a search bar. Empty placeholders look cheap.

## Phone tunnel
Four phones sit around a `perspective: 760px` box. Top and bottom phones are landscape with `rotateX(∓58deg)` and origin at their outer edge. Left and right phones are portrait with `rotateY(±58deg)`. Fly them in from the corners with `expo.out`, then push the whole box forward with `scale 1 → 1.1`.

## Glass meter + arcs of light
Use a glass pill whose fill grows from 7 to 100% (`scaleX` from the left) while a counter updates in `onUpdate`. Six concentric arcs sit at the bottom-right corner inside an HTML layer and scale 0.3 → 1.5.

## Sound design
Levelled pro sounds (−20 LUFS) quiet under the voice:
- shimmer on sparkles and the logo;
- a reverse whoosh into a flash, with a sub drop on the flash;
- soft swooshes on camera moves;
- small blips on fills and pops;
- a lens-flare sound on a colour wipe.

## Voice
Write every line the way the speaker actually talks (Egyptian markers in each line), then transcribe it with ElevenLabs scribe to check it. Respell any word it misreads.

---

# Moves added on 2026-11-02 (days 3–5)

## Draw a line (the rule that matters)
GSAP rounds `strokeDashoffset` to whole pixels. With `pathLength="1"` the line jumps from hidden to full in one frame. Use 1000:
```html
<path d="…" pathLength="1000" stroke-dasharray="1000 1500" stroke-dashoffset="1250" stroke-linecap="round"/>
```
```js
tl.to(path, { strokeDashoffset: 0, duration: 0.9, ease: "power2.inOut" }, t);   // a ring at 86%: strokeDashoffset: 140
```
The 1500 gap and 1250 start keep a round cap from painting a dot before the line starts.

## A wire that travels and wraps
The same dash, shorter, moving all the way through: `stroke-dasharray="600 1500"`, offset 650 → −1050. A segment comes in, wraps the object and leaves.

## Counters that survive any seek
```js
const DRV = new Map(); let CUR_C = 0;                       // CUR_C = start of the current loop cycle
const drive = (el, at, d, from, to, ease, apply) => { /* push a hold at CUR_C once, then {at,d,from,to} */ };
const render = () => { const t = tl.time(); for (const [el, segs] of DRV) { /* latest segment with at <= t, eased */ } };
tl.to({}, { duration: END, ease: "none", onUpdate: render }, 0);
```
Use it for numbers (0 → 12,480), a font weight (200 → 1000) and anything set by hand.

## Rolling digits (odometer)
Each digit is a window 50 px tall over a strip of 20 digits (0–9 twice). Tween the strip `y` to `-(10 + digit) * 50`, a little longer for each digit. The real motion blur does the rest.

## One liquid shape for everything
Write every shape as the same 8 cubic segments (a rounded rectangle with its own width, height, radius and edge wobble), so GSAP can tween `attr: { d }` from any shape to any other: puddle → squircle → list card → wide card → phone → dot.
```js
const rr = (w, h, r, j = 0) => { /* M top-left, 8 × C: top edge, TR corner, right edge, BR, bottom, BL, left, TL, Z */ };
tl.to(".shape", { attr: { d: SH.list }, duration: 0.45, ease: "back.out(1.4)" }, t);
```
Fill with a translucent gold gradient plus a rim stroke on a second path with the same `d`, and a glow behind. Land each new form with `elastic.out(1, 0.45)`.

## 16-tile poster
A 4×4 grid of tiles, each a tiny move on one period (6.4 s) repeated 3 times: `tl.set` the start state at each cycle, run the move, fade the tile's inner layer out 0.35 s before the next cycle. The title swaps its last word every 1.6 s. Keep labels short (`من ← إلى`).

## A line that writes itself with a light dot (Arabic-safe)
Words are spans with `display: none`, switched on one by one with `tl.set` plus a blur-in. Switching whole words keeps Arabic letters joined. The glowing dot is the last inline element, so it rides at the end of the line. To rewrite the ending, switch the last words off again and switch the new one on.

## Word bars
Full-height bars alternate gold and black and slam in from alternate sides (`expo.out`). Each carries one word rotated −90° (Arabic then reads top to bottom) that drifts the other way. Order them right to left for Arabic. End with a gold `clip-path` flood.

## Drift-in hero
The object enters from a corner with a big rotation (−72° → 26°, `power3.out`). Two soft dark tracks draw behind it, the title drops with `back.out(1.3)`, and a slow 1.045 push-in runs to the end. Spinning objects get `data-motion-blur="off"`.
