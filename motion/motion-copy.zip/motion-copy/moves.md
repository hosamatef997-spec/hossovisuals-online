# The moves (GSAP inside a HyperFrames page)

`tl` is the one paused timeline. Times are in seconds.

## Whip with motion blur (directional, no hard box edges)
```html
<svg width="0" height="0" style="position:absolute">
  <filter id="mb" x="-60%" y="-30%" width="220%" height="160%"><feGaussianBlur id="mb-g" stdDeviation="0 0" /></filter>
</svg>
<div id="name" style="filter:url(#mb)">YOUR NAME</div>
```
```js
tl.fromTo("#name", { x: -1900 }, { x: 0, duration: 0.24, ease: "expo.out" }, 4.38);
tl.fromTo("#mb-g", { attr: { stdDeviation: "90 0" } }, { attr: { stdDeviation: "0 0" }, duration: 0.26, ease: "power2.out" }, 4.38);
```
Keep the filter region wide (x -60%, width 220%), or the blur gets cut into a box.

## Text that inverts over the silhouette
```css
.dif { mix-blend-mode: difference; color: #fff; } /* dark over light, light over dark */
```
Put `.dif` on the moving element itself. A parent with a transform, opacity or filter isolates the blend, and the text then turns flat white.
For a part that must stay one solid colour (an accent slash or dot), use a second layer at the same position. Its letters are `color: transparent` and only the accent part shows.

## Letters falling one by one
```js
[...document.querySelectorAll("#name span")].forEach((el, i) =>
  tl.to(el, { y: 820, rotation: i % 2 ? 24 : -20, duration: 0.36, ease: "power2.in" }, 5.8 + i * 0.04));
```
Each letter is an inline-block `<span>`.

## Toggle → knob blooms into the next scene
```js
tl.to("#knob", { scale: 0.92, duration: 0.05 }, 9.4);                                   // press
tl.to("#knob", { x: 320, duration: 0.17, ease: "power3.inOut" }, 9.45);                 // slide
tl.to("#knob", { scaleX: 1.25, scaleY: 0.9, duration: 0.085 }, 9.45);                   // squash
tl.to("#knob", { scaleX: 1, scaleY: 1, duration: 0.12 }, 9.535);
tl.to("#knob", { scale: 10.5, duration: 0.25, ease: "power2.in" }, 10.15);              // bloom to fill the frame
```

## Word scramble before it lands
```js
tl.set("#word", { textContent: "K#V%A &ZQ" }, 10.5);
tl.set("#word", { textContent: "Brand &ZQ" }, 10.54);
tl.set("#word", { textContent: "Brand Films" }, 10.58);
```
Write the scrambles out in advance; no `Math.random()` while it plays.

## Pen trace with points
- An SVG `<path pathLength="1000" stroke-dasharray="1000">`, tweened `strokeDashoffset` 1000 → 0.
- Small `<rect>` points fade in at the time the line reaches them, and the pen cursor `set`s to each point in turn.
- Draw the outline in two strokes, like the reference: one side first, then the other.

## Typing with live guides
- Letters start `display:none` and are switched on one by one with `tl.set`.
- Dashed guide lines and a "### px" label sit inside the same inline-block as the letters, so they follow the width.
- Then a marquee (scale from the top-left corner) and the selection frame with handles snaps in.
