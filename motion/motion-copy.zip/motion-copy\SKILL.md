---
name: motion-copy
description: Rebuild a motion-design reel move for move (same layout, timing, zooms, blurs) with your own name, photo and colours, using HyperFrames (HTML → video). Use when someone says "make me a video exactly like this one", sends a reel to recreate, or wants a reel restyled in their brand colours.
---

# Motion Copy: a reel, move for move, with your identity

Made by HOSSO | VISUALS (@hossovisuals.ae). The output is a video that moves exactly like the reference. Only the person changes: name, photo or silhouette, work, colours.

## 0. Before you start
- You need Node.js 18+, ffmpeg, and HyperFrames (`npx hyperframes --help`, no install needed).
- Ask the user for four things: the reference video file, their name and title, a photo of them (for the silhouette), and their brand colours.
- Use the reference to learn from. Never reuse its audio, its logo or the other creator's name. Make new music in the same style.

## 1. Real frames, never a description
- A text summary of a video misses most moves. Work from frames.
- First check the reference's size: `ffprobe -v error -select_streams v -show_entries stream=width,height,r_frame_rate -of csv=p=0 ref.mp4`. Build on the same canvas, whether 16:9 or 9:16.
- Map the whole video at 0.1 s: `bash tools/frame-sheet.sh ref.mp4 <start> 0.1 sheet.jpg` gives 16 frames with timestamps per sheet. Step through it all.
- If you only have a web page with the video, paste `tools/frame-sheet-browser.js` into the page console, then `await sheet(0, 0.25, 16, 4)` and screenshot.
- Take one full-size still of every layout and measure in its pixels: each block's left/top, the font size (cap height ÷ 0.73 for Inter), and the colours.

## 2. Write the move list
For every scene, write down what enters and from where, the ease, any motion blur, zoom in or out, and the exact time.
Do not skip the small beats: a 1-frame grey flash, a knob that pulses before the click, a dot that bounces, letters falling one by one, a scramble before a word lands. They are what makes it feel "the same".

## 3. Build (one generator script → one HyperFrames page)
- Keep every number in one script that writes `project/index.html`. Changing the colours or the name is then one edit.
- One paused GSAP timeline, registered on `window.__timelines["main"]`. Every element has a fixed position, and only transforms and opacity are animated.
- The core moves are in `moves.md`: whip with motion blur, text that inverts over the silhouette, the falling letters, the knob that blooms into the next scene, the word scramble, the pen trace, the marquee → frame.
- More in `moves.md`: drawn lines (always `pathLength="1000"`: GSAP rounds the dash offset to whole pixels), counters driven by the timeline time, the odometer, one liquid shape that morphs into everything, the 16-tile poster, a line that writes itself with a light dot (Arabic-safe), word bars, and the drift-in hero.
- Real things beat placeholders: the person's photo inside cards, real UI words in their language, and a drawn object (camera, phone) with shading when no photo exists.
- Silhouette: cut the person out of the photo (rembg), find the outer contour, and smooth it into one SVG path. Carry the shoulder past the frame edge so no straight cut shows.

## 4. Compare, fix, deliver
- Render, make the same sheets of your render at the same times, and put them next to the reference sheets. Fix every difference in size, position or timing, then compare again.
- `npx hyperframes check` must show 0 errors.
- Final render: `npx hyperframes render -o out.mp4 --fps 60 -q delivery`. Instagram and TikTok play up to 60 fps; keep a 120 fps master if you like.
- Even out the sound: `ffmpeg -i out.mp4 -c:v copy -af loudnorm=I=-14:TP=-1.5 -c:a aac final.mp4`.
- Voice version: write the lines the way the person talks, transcribe each take to check it, and cut a line at its pauses so each phrase lands on the stage it names.
- Brand colours: swap colours by role. Background, ink, accent and the inverted scene each get one colour, so the contrast logic stays the same.
