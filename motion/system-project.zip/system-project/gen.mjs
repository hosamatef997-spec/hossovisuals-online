// Exact remake of inspiration DXzurbATRQT (abstract glowing-shape manifesto, 9:16, 33 s) in HOSSO identity:
// black #0D0C0A, gold #AD8330 → light gold #F2D28A glows, ivory scene, Arabic lines in Cairo, HOSSO logo end card.
// Timing and moves follow the original frame by frame (mapped at 0.2 s). node gen.mjs [--voice] → project/ or project-vo/
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const STUDIO = path.resolve(HERE, "../..");
const VOICE = process.argv.includes("--voice");
const OUT = path.join(HERE, VOICE ? "project-vo" : "project");
const C = { bg: "#0D0C0A", ivory: "#E8E7E3", paper: "#EEEBE3", gold: "#AD8330", hi: "#F2D28A", deep: "#5A3E12", amber: "#C9762C" };
const END = 33.0, CX = 540, CY = 958;
const T = { s1: 0, s2: 2.3, s3: 5.0, s4: 6.6, s5: 9.6, s6: 14.8, s7: 22.4, s8: 25.4, s9: 29.8 };

// ---- shape paths (same 4-cubic structure so GSAP can tween "d" between them)
const k = 0.5523;
const circle = (r) => `M 0 ${-r} C ${r * k} ${-r} ${r} ${-r * k} ${r} 0 C ${r} ${r * k} ${r * k} ${r} 0 ${r} C ${-r * k} ${r} ${-r} ${r * k} ${-r} 0 C ${-r} ${-r * k} ${-r * k} ${-r} 0 ${-r} Z`;
const squircle = (r) => `M 0 ${-r} C ${r * 0.82} ${-r} ${r} ${-r * 0.82} ${r} 0 C ${r} ${r * 0.82} ${r * 0.82} ${r} 0 ${r} C ${-r * 0.82} ${r} ${-r} ${r * 0.82} ${-r} 0 C ${-r} ${-r * 0.82} ${-r * 0.82} ${-r} 0 ${-r} Z`;
const star = (r) => `M 0 ${-r} C ${r * 0.12} ${-r * 0.2} ${r * 0.2} ${-r * 0.12} ${r} 0 C ${r * 0.2} ${r * 0.12} ${r * 0.12} ${r * 0.2} 0 ${r} C ${-r * 0.12} ${r * 0.2} ${-r * 0.2} ${r * 0.12} ${-r} 0 C ${-r * 0.2} ${-r * 0.12} ${-r * 0.12} ${-r * 0.2} 0 ${-r} Z`;
const sparkle = (r) => star(r);

const DOTS = [230, 385, 540, 695, 850];
// the node graph in s6, in world pixels (the camera moves the world): [text, x, y]
const W_PILLS = [["ابدأ بالهيكل", 540, 958], ["اعمل إيقاع", 1480, 1520], ["ادّي معنى", 2380, 860]];
const W_LINES = [
  ["s6-l1", "M 1120 1990 C 980 1850, 760 1880, 760 1700 S 520 1420, 600 1300 S 540 1150, 540 1053"],
  ["s6-l2", "M 925 958 C 1010 958, 1060 1120, 1080 1250 S 1200 1060, 1350 1080 S 1480 1250, 1480 1425"],
  ["s6-l3", "M 1480 1615 C 1480 1800, 1700 1820, 1820 1600 S 2100 1050, 2380 955"],
  ["s6-l4", "M 2725 860 C 2800 760, 2880 760, 2940 860 S 3080 960, 3140 860 S 3280 760, 3340 860"],
];
// the s7 outline pill, drawn from its top-right corner leftwards
const PILL_PATH = "M 790 863 L 290 863 A 95 95 0 0 0 290 1053 L 790 1053 A 95 95 0 0 0 790 863 Z";
const WORDS6 = ["ملف", "المشروع", "في", "الكابشن"];
// ---- the lines (on screen); the voice version reads them in Egyptian
const L = {
  s1: "يلا نبدأ", s2: "بنظام واضح", s3a: "بندوّر", s3b: "على الشكل", s4a: "الشكل", s4b: "بيحدد التركيز",
  s5: "والتركيز بيرتّب الحركة", p2: "اعمل إيقاع", p3: "ادّي معنى", s7: "متوصّل", s8a: "فكرة", s8b: "بتتحرك",
};
const VO = [ // [file, start] — lines in tts script order
  ["01.mp3", 0.5], ["02.mp3", 2.6], ["03.mp3", 5.5], ["04.mp3", 7.6], ["05.mp3", 10.0], ["06.mp3", 15.0], ["07.mp3", 17.9], ["08.mp3", 20.4], ["09.mp3", 23.4], ["10.mp3", 26.0], ["11.mp3", 30.0],
];
const SFX = [ // [file under assets/sfx, at, volume] — pro/* are levelled to −20 LUFS
  ["pro/09-ui-riser-short.wav", 0.02, 0.10], ["pro/20-shimmer.wav", 0.55, 0.10], ["lib/ui-2.wav", 0.78, 0.04], ["lib/ui-2.wav", 0.98, 0.04],
  ["pro/06-reverse-whoosh.wav", 0.0, 0.0], ["pro/03-reverb-woosh.wav", 1.5, 0.16], ["pro/01-future-move.wav", 2.35, 0.12], ["pro/05-glitch-glide.wav", 2.56, 0.10],
  ["pro/08-transition-swish.wav", 3.9, 0.14], ["pro/08-transition-swish.wav", 4.12, 0.12], ["pro/03-reverb-woosh.wav", 4.78, 0.14], ["pro/20-shimmer.wav", 5.0, 0.07],
  ["pro/12-blip-then-hit.wav", 6.0, 0.12], ["lib/click-4.wav", 6.62, 0.05], ["pro/12-blip-then-hit.wav", 6.8, 0.12], ["pro/02-cinematic-swoosh-pass.wav", 7.36, 0.18],
  ["pro/02-whoosh-soft.wav", 8.58, 0.16], ["lib/ui-5.wav", 9.4, 0.05], ["lib/click-1.wav", 9.85, 0.05],
  ["lib/click-3.wav", 10.0, 0.05], ["lib/click-4.wav", 10.2, 0.05], ["lib/click-3.wav", 10.4, 0.05], ["lib/click-4.wav", 10.6, 0.05], ["lib/click-1.wav", 10.8, 0.05],
  ["pro/09-ui-riser-short.wav", 13.15, 0.12], ["pro/06-reverse-whoosh.wav", 12.6, 0.14], ["pro/04-ripple-bloom.wav", 14.52, 0.22], ["pro/08-sub-drop.wav", 14.55, 0.32],
  ["pro/12-blip-then-hit.wav", 15.0, 0.10], ["pro/12-blip-then-hit.wav", 16.98, 0.12], ["pro/02-cinematic-swoosh-pass.wav", 17.35, 0.16], ["pro/12-blip-then-hit.wav", 18.55, 0.12],
  ["pro/02-cinematic-swoosh-pass.wav", 19.3, 0.16], ["pro/12-blip-then-hit.wav", 20.78, 0.12], ["pro/06-airy-swish.wav", 21.6, 0.14], ["pro/037-lens-flare-transition-sound-effect.wav", 22.0, 0.2],
  ["pro/01-future-move.wav", 23.15, 0.12], ["lib/click-3.wav", 23.6, 0.04], ["lib/click-4.wav", 23.75, 0.04], ["lib/click-3.wav", 23.9, 0.04], ["pro/02-whoosh-soft.wav", 24.95, 0.16],
  ["pro/20-shimmer.wav", 25.5, 0.07], ["pro/06-airy-swish.wav", 25.85, 0.1], ["pro/06-airy-swish.wav", 28.0, 0.1], ["pro/05-bass-reverb.wav", 29.5, 0.24], ["pro/18-ding-gold.wav", 29.85, 0.14],
].filter(([, , v]) => v > 0);
const SFXROOT = { lib: path.join(STUDIO, "jobs/re-exact/project/assets/sfx/lib"), pro: path.join(HERE, "pro") };
const dur = (f) => +(+execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]).toString().trim()).toFixed(2);
const music = path.join(HERE, "project/assets/music.mp3");
const audio = [
  `<audio id="music" class="clip" src="assets/music.mp3" data-start="0" data-duration="${END}" data-volume="${VOICE ? 0.22 : 0.6}" data-track-index="9"></audio>`,
  ...SFX.map(([f, at, v], i) => `<audio id="fx${i}" class="clip" src="assets/sfx/${f}" data-start="${at}" data-duration="${dur(path.join(SFXROOT[f.split("/")[0]], f.split("/")[1]))}" data-volume="${(v * (VOICE ? 0.8 : 1)).toFixed(3)}" data-track-index="${10 + (i % 6)}"></audio>`),
  ...(VOICE ? VO.map(([f, at], i) => `<audio id="vo${i}" class="clip" src="assets/vo/${f}" data-start="${at}" data-duration="${dur(path.join(HERE, "vo", f))}" data-volume="1" data-track-index="${20 + (i % 2)}"></audio>`) : []),
].join("\n  ");

const scene = (id, a, b, inner, cls = "") => `<div id="${id}" class="scene clip ${cls}" data-start="${a}" data-duration="${(b - a).toFixed(2)}" data-track-index="1">${inner}</div>`;
const svg = (inner, id = "") => `<svg ${id ? `id="${id}" ` : ""}class="full" viewBox="0 0 1080 1920" width="1080" height="1920">${inner}</svg>`;

const html = `<!doctype html>
<html><head><meta charset="utf-8" />
<style>
  @font-face { font-family: "Cairo"; src: url("assets/fonts/cairo-arabic.woff2") format("woff2"); font-weight: 200 1000; unicode-range: U+0600-06FF, U+FE70-FEFF, U+200C-200F; }
  html, body { margin: 0; background: ${C.bg}; }
  #root { position: relative; width: 1080px; height: 1920px; overflow: hidden; background: ${C.bg}; font-family: "Cairo", "Inter", sans-serif; }
  .scene { position: absolute; inset: 0; overflow: hidden; }
  .full { position: absolute; left: 0; top: 0; width: 1080px; height: 1920px; overflow: visible; }
  .ph { position: absolute; left: 0; right: 0; text-align: center; direction: rtl; font-weight: 300; font-size: 56px; line-height: 1.2; color: ${C.ivory}; white-space: nowrap; }
  .ph b { font-weight: 300; }
  .paper { background: ${C.paper}; }
  .pill { position: absolute; left: ${CX - 345}px; top: ${CY - 95}px; width: 690px; height: 190px; border-radius: 95px; background: ${C.bg}; box-shadow: 0 0 0 2px rgba(255,255,255,.08) inset, 0 18px 40px rgba(0,0,0,.25); display: flex; align-items: center; justify-content: center; gap: 30px; direction: rtl; }
  .pill span { font-weight: 300; font-size: 58px; color: ${C.ivory}; white-space: nowrap; }
  .pill svg { width: 64px; height: 64px; overflow: visible; }
  .pill .gd { position: absolute; inset: 0; border-radius: 95px; background: linear-gradient(90deg, ${C.deep}, ${C.gold} 55%, ${C.hi}); opacity: 0; }
  #foot { position: absolute; left: 0; right: 0; top: 1652px; text-align: center; direction: rtl; font-size: 36px; color: ${C.bg}; white-space: nowrap; }
  #foot span { font-weight: 400; }
  #s4-card { position: absolute; left: 120px; top: ${CY - 115}px; width: 840px; height: 230px; border-radius: 40px; background: #F3ECDD; overflow: hidden; }
  #s4-card i { position: absolute; inset: 0; background: linear-gradient(90deg, #F3ECDD 0%, ${C.hi} 55%, ${C.gold} 100%); opacity: 0; }
  #s4-big { position: absolute; left: -10px; top: ${CY - 210}px; width: 1130px; height: 420px; border-radius: 36px 0 0 36px; border: 2px solid rgba(255,240,210,.45); border-right: 0; background: linear-gradient(90deg, #100A04 0%, ${C.deep} 32%, ${C.gold} 68%, ${C.hi} 100%); }
  #s4-t1 { position: absolute; right: 460px; top: ${CY - 92}px; font-weight: 600; font-size: 84px; color: ${C.ivory}; direction: rtl; white-space: nowrap; }
  #s4-t2 { position: absolute; right: 460px; top: ${CY + 10}px; font-weight: 300; font-size: 50px; color: rgba(232,231,227,.85); direction: rtl; white-space: nowrap; }
  #logo { position: absolute; left: 0; right: 0; margin: auto; top: 840px; width: 520px; }
  #url { position: absolute; left: 0; right: 0; top: 1030px; text-align: center; font: 400 30px "JetBrains Mono", monospace; letter-spacing: .08em; color: ${C.hi}; }
  .lyr { position: absolute; inset: 0; }
  .blob { position: absolute; border-radius: 50%; filter: blur(46px); mix-blend-mode: screen; }
</style></head>
<body>
<div id="root" data-motion-blur="on" data-motion-blur-shutter="220" data-composition-id="main" data-width="1080" data-height="1920" data-duration="${END}">
  <svg width="0" height="0" style="position:absolute">
    <defs>
      <linearGradient id="gGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${C.deep}" /><stop offset=".5" stop-color="${C.gold}" /><stop offset="1" stop-color="${C.hi}" /></linearGradient>
      <linearGradient id="gArc" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${C.amber}" /><stop offset=".5" stop-color="${C.gold}" /><stop offset="1" stop-color="${C.hi}" /></linearGradient>
      <radialGradient id="gDisc"><stop offset="0" stop-color="#FFF3D6" /><stop offset=".3" stop-color="${C.hi}" /><stop offset=".62" stop-color="${C.gold}" stop-opacity=".75" /><stop offset="1" stop-color="${C.deep}" stop-opacity="0" /></radialGradient>
      <radialGradient id="gHalo"><stop offset="0" stop-color="${C.hi}" stop-opacity=".9" /><stop offset=".5" stop-color="${C.gold}" stop-opacity=".45" /><stop offset="1" stop-color="${C.gold}" stop-opacity="0" /></radialGradient>
      <radialGradient id="gBloom"><stop offset="0" stop-color="#FFFDF7" /><stop offset=".72" stop-color="${C.paper}" /><stop offset=".86" stop-color="${C.hi}" /><stop offset="1" stop-color="${C.gold}" stop-opacity="0" /></radialGradient>
      <linearGradient id="gTop" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.gold}" /><stop offset=".6" stop-color="${C.deep}" stop-opacity=".6" /><stop offset="1" stop-color="${C.bg}" stop-opacity="0" /></linearGradient>
      <filter id="fGlow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="22" /></filter>
      <filter id="fSoft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="9" /></filter>
      <filter id="fBig" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="40" /></filter>
      <filter id="fGlitch" x="-20%" y="-60%" width="140%" height="220%"><feTurbulence type="fractalNoise" baseFrequency=".012 .22" numOctaves="1" seed="4" /><feDisplacementMap id="fGlitch-d" in="SourceGraphic" scale="0" xChannelSelector="R" yChannelSelector="G" /></filter>
    </defs>
  </svg>

  ${scene("s1", T.s1, T.s2, `
    ${svg(`<rect id="s1-top" x="0" y="-200" width="1080" height="1100" fill="url(#gTop)" opacity="0" />
      <ellipse id="s1-bot" cx="${CX}" cy="1960" rx="760" ry="300" fill="url(#gDisc)" filter="url(#fBig)" opacity="0" />`)}
    <div id="s1-sp" style="position:absolute;inset:0;transform-origin:${CX}px 920px">
      ${svg(`<path id="s1-sine" d="M ${CX} 1920 C ${CX + 260} 1760, ${CX + 260} 1560, ${CX} 1400 S ${CX - 260} 1080, ${CX} 920" fill="none" stroke="${C.ivory}" stroke-width="2" stroke-dasharray="1 7" stroke-linecap="round" opacity="0" />`)}
      <div id="s1-ln" style="position:absolute;left:${CX - 1}px;top:920px;width:2px;height:1000px;background:${C.hi};opacity:.85;transform-origin:50% 100%"></div>
      ${[[920, 170, 32], [1400, 470, 84], [1890, 600, 120]].map(([y, rx, ry], i) => `<div id="s1-d${i}" style="position:absolute;left:${CX - rx}px;top:${y - ry}px;width:${rx * 2}px;height:${ry * 2}px;transform-origin:50% 50%"><div style="position:absolute;inset:-30%;border-radius:50%;background:radial-gradient(closest-side,#FFF3D6 0%,${C.hi} 30%,rgba(173,131,48,.7) 62%,rgba(90,62,18,0) 100%);filter:blur(${Math.round(ry * 0.35)}px)"></div><div style="position:absolute;left:11%;right:11%;top:29%;bottom:29%;border-radius:50%;background:radial-gradient(closest-side,#FFF8E6,rgba(255,243,214,0));filter:blur(${Math.round(ry * 0.12)}px)"></div></div>`).join("")}
      <div id="s1-dot" style="position:absolute;left:${CX - 10}px;top:910px;width:20px;height:20px;border-radius:50%;background:#fff"></div>
      <div id="s1-dot2" style="position:absolute;left:${CX - 47}px;top:1003px;width:14px;height:14px;border-radius:50%;background:#fff"></div>
    </div>
    <div id="s1-t" class="ph" style="top:575px">${L.s1}</div>`)}

  ${scene("s2", T.s2, T.s3, `
    <div id="s2-rot" class="lyr" data-motion-blur="off">${svg(`
      <g transform="translate(${CX} ${CY})">
        <g>
          <path id="s2-glow" d="${circle(300)}" fill="none" stroke="url(#gArc)" stroke-width="54" stroke-dasharray="640 820" filter="url(#fGlow)" opacity=".9" />
          <path id="s2-ring" d="${circle(300)}" fill="none" stroke="${C.ivory}" stroke-width="2.5" />
        </g></g>`)}</div>
    <div id="s2-dots" class="lyr" data-motion-blur="off">${svg(`<g transform="translate(${CX} ${CY})"><g>${[45, 135, 225, 315].map((a, i) => `<circle class="s2-dot" id="s2-dot${i}" cx="${(Math.cos((a * Math.PI) / 180) * 200).toFixed(1)}" cy="${(Math.sin((a * Math.PI) / 180) * 200).toFixed(1)}" r="13" fill="#fff" />`).join("")}</g></g>`)}</div>
    <div id="s2-t" class="ph" style="top:${CY - 40}px;filter:url(#fGlitch)">${L.s2}</div>`)}

  ${scene("s3", T.s3, T.s4, `
    <div id="s3-sp" class="lyr" data-motion-blur="off">${svg(`<g transform="translate(${CX} ${CY})"><g><path d="${sparkle(46)}" fill="none" stroke="url(#gGold)" stroke-width="4" filter="url(#fSoft)" /><path id="s3-spf" d="${sparkle(46)}" fill="url(#gGold)" stroke="${C.hi}" stroke-width="3" fill-opacity="0" /></g></g>`)}</div>
    <div class="ph" style="top:${CY + 120}px"><span id="s3-a">${L.s3a}</span> <span id="s3-b">${L.s3b}</span></div>`)}

  ${scene("s4", T.s4, T.s5, `
    <div id="s4-wrap" style="position:absolute;inset:0">
      ${svg(`<rect id="s4-bar" x="${CX - 60}" y="${CY - 7}" width="120" height="14" rx="7" fill="url(#gGold)" />`)}
      <div id="s4-card"><i id="s4-cg"></i>${svg(`<g transform="translate(${CX - 120} ${115 - (CY - 115) + (CY - 115)})"></g>`)}</div>
      <div id="s4-big"></div>
      <div id="s4-t1">${L.s4a}</div><div id="s4-t2">${L.s4b}</div>
    </div>
    <div id="s4-star" class="lyr" data-motion-blur="off" style="transform-origin:790px ${CY}px"><div id="s4-stari" class="lyr" style="transform-origin:790px ${CY}px">${svg(`<g transform="translate(790 ${CY})"><g><g><path d="${star(110)}" fill="none" stroke="${C.ivory}" stroke-width="10" filter="url(#fSoft)" opacity=".7" /><path d="${star(110)}" fill="none" stroke="url(#gGold)" stroke-width="4" /></g></g></g>`)}</div></div>`)}

  ${scene("s5", T.s5, T.s6, `
    ${svg(`
      <g id="s5-cam">
        ${DOTS.map((x, i) => `<g id="s5-g${i}"><rect id="s5-bar${i}" x="${x - 1}" y="${CY}" width="2" height="1400" fill="${C.ivory}" opacity="0" /><circle id="s5-h${i}" cx="${x}" cy="${CY}" r="34" fill="url(#gHalo)" opacity="0" /><rect id="s5-tk${i}" x="${x - 1}" y="${CY + 16}" width="2" height="40" fill="${C.ivory}" opacity=".7" /><circle id="s5-d${i}" cx="${x}" cy="${CY}" r="10" fill="#fff" /></g>`).join("")}
        ${DOTS.slice(0, 4).map((x, i) => `<path id="s5-arc${i}" d="M ${x} ${CY - 6} C ${x} ${CY - 150}, ${DOTS[i + 1]} ${CY - 150}, ${DOTS[i + 1]} ${CY - 6}" fill="none" stroke="url(#gArc)" stroke-width="10" stroke-linecap="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" />`).join("")}
      </g>
      <circle id="s5-fall" cx="790" cy="280" r="10" fill="#fff" />
      <rect id="s5-pill" x="${CX - 140}" y="${CY - 32}" width="280" height="64" rx="32" fill="url(#gArc)" opacity="0" />`)}
    <div id="s5-bloom"  data-motion-blur="off"style="position:absolute;left:${CX - 200}px;top:${CY - 200}px;width:400px;height:400px;border-radius:50%;opacity:0;background:radial-gradient(closest-side,#FFFDF7 0%,${C.paper} 72%,${C.hi} 86%,rgba(173,131,48,0) 100%)"></div>
    <div id="s5-t" class="ph" style="top:${CY + 200}px;font-size:50px">${L.s5}</div>`)}

  ${scene("s6", T.s6, T.s7, `
    <div class="paper" style="position:absolute;inset:0"></div>
    <div id="s6-world" style="position:absolute;left:0;top:0;width:3600px;height:2600px">
      <svg id="s6-lines" style="position:absolute;left:0;top:0;overflow:visible" width="3600" height="2600" viewBox="0 0 3600 2600">
        <defs>${W_LINES.map(([id, d]) => `<mask id="m-${id}" maskUnits="userSpaceOnUse" x="-200" y="-200" width="4000" height="3000"><path id="${id}" d="${d}" fill="none" stroke="#fff" stroke-width="14" stroke-linecap="round" pathLength="1000" stroke-dasharray="1000" stroke-dashoffset="1000" /></mask>`).join("")}</defs>
        ${W_LINES.map(([id, d]) => `<path d="${d}" fill="none" stroke="#2A2722" stroke-width="3" stroke-dasharray="2 8" stroke-linecap="round" mask="url(#m-${id})" />`).join("")}
        <path id="s6-arrow" d="M 900 958 l 22 0 m -9 -9 l 9 9 l -9 9" fill="none" stroke="#2A2722" stroke-width="3" opacity="0" />
        <circle id="s6-dot" cx="1120" cy="1990" r="10" fill="#2A2722" />
      </svg>
      ${W_PILLS.map(([t, x, y], i) => `<div id="s6-p${i}" class="pill" style="left:${x - 345}px;top:${y - 95}px"><i class="gd"></i><svg viewBox="-40 -40 80 80"><path d="${sparkle(34)}" fill="none" stroke="url(#gGold)" stroke-width="4" /></svg><span>${t}</span></div>`).join("\n      ")}
    </div>
    <div id="s6-wipe" style="position:absolute;top:0;left:-1600px;width:1600px;height:1920px;background:linear-gradient(90deg, ${C.bg} 0%, ${C.bg} 38%, ${C.deep} 55%, ${C.gold} 72%, ${C.hi} 84%, rgba(242,210,138,0) 100%)" data-motion-blur="off"></div>`)}

  ${scene("s7", T.s7, T.s8, `
    ${svg(`
      <path id="s7-l" d="M 250 ${CY} L 330 ${CY}" stroke="${C.ivory}" stroke-width="2.5" fill="none" stroke-dasharray="2 8" stroke-linecap="round" />
      <path id="s7-arc" d="M 560 ${CY} C 680 ${CY}, 760 930, 790 ${CY - 95}" stroke="url(#gArc)" stroke-width="8" fill="none" stroke-linecap="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" />
      <circle id="s7-dot" cx="330" cy="${CY}" r="10" fill="#fff" />`)}
    <div id="s7-w" class="lyr" data-motion-blur="off" style="transform-origin:${CX}px ${CY}px">
      ${svg(`<path id="s7-pglow" d="${PILL_PATH}" fill="none" stroke="url(#gArc)" stroke-width="16" filter="url(#fSoft)" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" />
      <path id="s7-p" d="${PILL_PATH}" fill="none" stroke="${C.hi}" stroke-width="3" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" />`)}
      <div id="s7-t" class="ph" style="top:${CY - 40}px;font-size:58px">${L.s7}</div>
    </div>`)}

  ${scene("s8", T.s8, T.s9, `
    <div id="s8-blobs" class="lyr" data-motion-blur="off">
      <div id="s8-b0" class="blob" style="left:${CX - 130}px;top:${CY - 130}px;width:260px;height:260px;background:${C.gold}"></div>
      <div id="s8-b1" class="blob" style="left:${CX - 115}px;top:${CY - 115}px;width:230px;height:230px;background:${C.amber}"></div>
      <div id="s8-b2" class="blob" style="left:${CX - 105}px;top:${CY - 105}px;width:210px;height:210px;background:${C.hi}"></div>
    </div>
    <div id="s8-t" class="ph" style="top:${CY - 40}px;z-index:3;text-shadow:0 2px 18px rgba(13,12,10,.55)">${L.s8a} ${L.s8b}</div>`)}

  ${scene("s9", T.s9, END, `<div id="s9-flash" style="position:absolute;left:${CX - 300}px;top:${CY - 300}px;width:600px;height:600px;border-radius:50%;background:radial-gradient(closest-side, rgba(255,243,214,.9), rgba(242,210,138,.35) 45%, rgba(173,131,48,0) 100%)" data-motion-blur="off"></div><img id="logo" src="assets/hosso-light.png" alt="HOSSO" data-motion-blur="off" /><div id="url">hossovisuals.online</div>`)}

  <div id="foot" class="clip" data-start="${T.s6}" data-duration="${(END - T.s6).toFixed(2)}" data-track-index="3">${WORDS6.map((w, i) => `<span id="f${i}">${w}</span>`).join(" ")}</div>

  ${audio}
</div>

<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<script>
  const tl = gsap.timeline({ paused: true });
  const D = { c: ${JSON.stringify([300, 450, 470].map(circle))}, sq: "${squircle(420)}", st: "${star(300)}", st2: "${star(340)}" };

  // ---------- s1 · Let's begin: the line grows, discs of light stack and the camera pulls back, a gold wash, the dot rides on
  tl.fromTo("#s1-ln", { scaleY: 0 }, { scaleY: 1, duration: 0.4, ease: "power2.out" }, 0.08);
  tl.fromTo("#s1-dot", { y: 780 }, { y: 0, duration: 0.4, ease: "power2.out" }, 0.08);
  tl.fromTo("#s1-dot2", { x: -80, y: 500 }, { x: 0, y: 0, duration: 0.5, ease: "power2.out" }, 0.12);
  tl.fromTo("#s1-sine", { opacity: 0 }, { opacity: 0.75, duration: 0.3 }, 0.12);
  ${[0.55, 0.75, 0.95].map((t, i) => `tl.fromTo("#s1-d${i}", { scaleX: 0.1, scaleY: 0.3, opacity: 0 }, { scaleX: 1, scaleY: 1, opacity: 1, duration: 0.28, ease: "expo.out" }, ${t});`).join(" ")}
  tl.fromTo("#s1-sp", { scale: 1.28, y: 60 }, { scale: 0.8, y: -40, duration: 1.0, ease: "power1.inOut" }, 0.5);
  tl.fromTo("#s1-t", { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.3, ease: "power2.out" }, 0.55);
  tl.to("#s1-top", { opacity: 1, duration: 0.06 }, 1.52); tl.to("#s1-top", { y: -900, opacity: 0, duration: 0.25, ease: "power2.in" }, 1.6);
  tl.to("#s1-t, #s1-d0, #s1-d1, #s1-d2, #s1-sine, #s1-ln, #s1-dot2", { opacity: 0, duration: 0.1 }, 1.55);
  tl.fromTo("#s1-bot", { opacity: 0 }, { opacity: 0.9, duration: 0.15 }, 1.68); tl.to("#s1-bot", { opacity: 0, duration: 0.45 }, 1.85);
  tl.set("#s1-sp", { scale: 1, y: 0 }, 1.6);
  tl.to("#s1-dot", { y: -500, duration: 0.25, ease: "power2.out" }, 1.62);
  tl.to("#s1-dot", { y: -280, duration: 0.5, ease: "sine.inOut" }, 1.9);

  // ---------- s2 · With a system: four dots orbit, the ring forms, the text glitches in, ring → squircle → star, then it collapses
  const s2 = ${T.s2};
  tl.fromTo("#s2-dots", { rotation: 0 }, { rotation: 200, transformOrigin: "50% 50%", duration: 2.7, ease: "none" }, s2);
  tl.fromTo("#s2-rot", { rotation: -30 }, { rotation: 150, transformOrigin: "50% 50%", duration: 2.7, ease: "none" }, s2);
  tl.fromTo("#s2-ring, #s2-glow", { opacity: 0 }, { opacity: 1, duration: 0.2 }, 2.55);
  tl.fromTo("#s2-ring, #s2-glow", { attr: { d: D.c[0] } }, { attr: { d: D.c[1] }, duration: 0.5, ease: "power2.out" }, 2.55);
  tl.to("#s2-ring, #s2-glow", { attr: { d: D.c[2] }, duration: 0.8, ease: "sine.inOut" }, 3.05);
  ${[0, 1, 2, 3].map((i) => `tl.fromTo("#s2-dot${i}", { attr: { cx: ${(Math.cos(((45 + i * 90) * Math.PI) / 180) * 200).toFixed(1)}, cy: ${(Math.sin(((45 + i * 90) * Math.PI) / 180) * 200).toFixed(1)} } }, { attr: { cx: ${(Math.cos(((45 + i * 90) * Math.PI) / 180) * 470).toFixed(1)}, cy: ${(Math.sin(((45 + i * 90) * Math.PI) / 180) * 470).toFixed(1)} }, duration: 0.6, ease: "power2.out" }, 2.55);
  tl.to("#s2-dot${i}", { attr: { cx: ${(Math.cos(((i * 90) - 90) * Math.PI / 180) * 300).toFixed(1)}, cy: ${(Math.sin(((i * 90) - 90) * Math.PI / 180) * 300).toFixed(1)} }, duration: 0.45, ease: "power2.inOut" }, 3.95);`).join("\n  ")}
  tl.to("#s2-ring, #s2-glow", { attr: { d: D.sq }, duration: 0.2, ease: "power2.in" }, 3.92);
  tl.to("#s2-ring, #s2-glow", { attr: { d: D.st }, duration: 0.25, ease: "power2.out" }, 4.12);
  tl.to("#s2-ring, #s2-glow", { attr: { d: D.st2 }, duration: 0.35, ease: "power2.out" }, 4.45);
  tl.to("#s2-rot, #s2-dots", { scale: 0.08, opacity: 0, transformOrigin: "50% 50%", duration: 0.2, ease: "power3.in" }, 4.8);
  tl.fromTo("#s2-t", { opacity: 0 }, { opacity: 1, duration: 0.15 }, 2.58);
  tl.fromTo("#fGlitch-d", { attr: { scale: 90 } }, { attr: { scale: 0 }, duration: 0.55, ease: "power2.out" }, 2.6);
  tl.to("#s2-t", { rotation: -9, scale: 1.08, duration: 0.3, ease: "power2.inOut" }, 4.5);
  tl.to("#s2-t", { opacity: 0, filter: "blur(10px)", duration: 0.18 }, 4.78);

  // ---------- s3 · Finding form: a small sparkle spins in 3D, the words land, it grows and fills, then flips thin
  const s3 = ${T.s3};
  tl.fromTo("#s3-sp", { scale: 0.2, rotation: 0 }, { scale: 0.55, rotation: 180, transformOrigin: "50% 50%", duration: 0.3, ease: "power3.out" }, s3);
  tl.to("#s3-sp", { scaleX: -0.55, duration: 0.25, yoyo: true, repeat: 3, ease: "sine.inOut" }, s3 + 0.3);
  tl.to("#s3-sp", { scale: 1.6, rotation: 225, duration: 0.3, ease: "back.out(2)" }, 6.0);
  tl.to("#s3-spf", { attr: { "fill-opacity": 1 }, duration: 0.2 }, 6.02);
  tl.to("#s3-sp", { scaleX: 0.08, duration: 0.15, ease: "power2.in" }, 6.35);
  tl.fromTo("#s3-a", { opacity: 0 }, { opacity: 1, duration: 0.2 }, 5.58);
  tl.fromTo("#s3-b", { opacity: 0 }, { opacity: 1, duration: 0.2 }, 5.82);
  tl.to("#s3-a, #s3-b", { opacity: 0, duration: 0.15 }, 6.45);

  // ---------- s4 · Form defines focus: a bar, an ivory pill, it fills gold, opens into a full-width card, then swings away
  const s4 = ${T.s4};
  tl.fromTo("#s4-bar", { scaleX: 0 }, { scaleX: 1, svgOrigin: "${CX} ${CY}", duration: 0.15, ease: "power2.out" }, s4);
  tl.set("#s4-bar", { opacity: 0 }, 6.8);
  tl.fromTo("#s4-card", { scaleX: 0.14, scaleY: 0.06, opacity: 0 }, { scaleX: 1, scaleY: 1, opacity: 1, duration: 0.22, ease: "expo.out" }, 6.8);
  tl.to("#s4-cg", { opacity: 1, duration: 0.35 }, 7.0);
  tl.set("#s4-card", { opacity: 0 }, 7.4);
  tl.fromTo("#s4-big", { scaleY: 0.55, opacity: 0 }, { scaleY: 1, opacity: 1, duration: 0.25, ease: "expo.out" }, 7.38);
  tl.fromTo("#s4-star", { opacity: 0, scale: 0.3 }, { opacity: 1, scale: 1, transformOrigin: "790px ${CY}px", duration: 0.3, ease: "back.out(2)" }, 6.85);
  tl.fromTo("#s4-t1", { clipPath: "inset(-20% 0 -20% 100%)" }, { clipPath: "inset(-20% 0 -20% 0%)", duration: 0.3, ease: "power2.out" }, 7.72);
  tl.fromTo("#s4-t2", { clipPath: "inset(-20% 0 -20% 100%)" }, { clipPath: "inset(-20% 0 -20% 0%)", duration: 0.35, ease: "power2.out" }, 7.88);
  tl.fromTo("#s4-wrap", { scale: 1 }, { scale: 1.05, transformOrigin: "50% 50%", duration: 0.95, ease: "none" }, 7.6);
  tl.to("#s4-wrap", { x: 950, rotationY: -55, transformPerspective: 1200, transformOrigin: "100% 50%", duration: 0.7, ease: "power2.in" }, 8.6);
  tl.to("#s4-stari", { rotation: 270, scale: 0.35, transformOrigin: "790px ${CY}px", duration: 0.7, ease: "power2.inOut" }, 8.6);
  tl.to("#s4-star", { x: -250, y: -490, duration: 0.7, ease: "power2.inOut" }, 8.6);
  tl.to("#s4-star", { scale: 0.08, opacity: 0, transformOrigin: "540px 470px", duration: 0.25, ease: "power2.in" }, 9.35);

  // ---------- s5 · Focus organizes motion: a dot falls into a row, a comet hops dot to dot, the row pulses, bars rise, one dot blooms
  const s5 = ${T.s5};
  tl.fromTo("#s5-fall", { attr: { cy: 280, cx: 790 } }, { attr: { cy: ${CY}, cx: 695 }, duration: 0.25, ease: "power2.in" }, s5);
  tl.set("#s5-fall", { opacity: 0 }, 9.86);
  ${DOTS.map((_, i) => `tl.fromTo("#s5-d${i}, #s5-tk${i}", { scale: 0, opacity: 0 }, { scale: 1, opacity: 1, svgOrigin: "${DOTS[i]} ${CY}", duration: 0.12, ease: "back.out(3)" }, ${(9.85 + i * 0.03).toFixed(2)});`).join("\n  ")}
  ${[0, 1, 2, 3].map((i) => `tl.fromTo("#s5-arc${i}", { strokeDashoffset: 100 }, { strokeDashoffset: 0, duration: 0.11, ease: "power1.out" }, ${(10.0 + i * 0.2).toFixed(2)}); tl.to("#s5-arc${i}", { strokeDashoffset: -100, duration: 0.12, ease: "power1.in" }, ${(10.11 + i * 0.2).toFixed(2)});`).join("\n  ")}
  tl.fromTo("#s5-t", { opacity: 0, color: "${C.gold}" }, { opacity: 1, color: "${C.ivory}", duration: 0.35 }, 10.0);
  ${Array.from({ length: 8 }, (_, b) => DOTS.map((_, i) => `tl.fromTo("#s5-h${i}", { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1.2, svgOrigin: "${DOTS[i]} ${CY}", duration: 0.12, yoyo: true, repeat: 1, ease: "sine.inOut" }, ${(10.85 + b * 0.25 + i * 0.04).toFixed(2)});`).join(" ")).join("\n  ")}
  ${[-12, 0, 12, 18, 18].map((dy, i) => `tl.to("#s5-g${i}", { y: ${dy}, duration: 0.25, ease: "sine.inOut" }, 12.85);`).join(" ")}
  ${DOTS.map((_, i) => `tl.set("#s5-bar${i}", { opacity: 0.75 }, 13.2); tl.to("#s5-g${i}", { y: ${-(i + 1) * 190}, duration: 0.3, ease: "power3.out" }, ${(13.2 + i * 0.05).toFixed(2)});`).join("\n  ")}
  tl.to("#s5-cam", { y: 640, duration: 0.45, ease: "power2.inOut" }, 13.32);
  tl.to("#s5-t", { opacity: 0, duration: 0.15 }, 13.4);
  ${[0, 1, 2, 3].map((i) => `tl.to("#s5-g${i}", { opacity: 0, duration: 0.12 }, 13.62);`).join(" ")}
  tl.to("#s5-cam", { x: ${CX - DOTS[4]}, duration: 0.25, ease: "power2.inOut" }, 13.62);
  tl.to("#s5-h4", { opacity: 1, scale: 1.8, svgOrigin: "${DOTS[4]} ${CY}", duration: 0.3, ease: "power2.out" }, 13.98);
  tl.to("#s5-bar4, #s5-tk4", { opacity: 0, duration: 0.2 }, 14.05);
  tl.to("#s5-g4", { y: ${-5 * 190 + 320}, duration: 0.45, ease: "power2.inOut" }, 14.02);
  tl.to("#s5-cam", { y: 320, duration: 0.45, ease: "power2.inOut" }, 14.02);
  tl.set("#s5-bloom", { opacity: 1 }, 14.5);
  tl.fromTo("#s5-bloom", { scale: 0.1 }, { scale: 6.5, transformOrigin: "50% 50%", duration: 0.3, ease: "power2.in" }, 14.5);
  tl.fromTo("#s5-pill", { opacity: 0, scale: 0.4 }, { opacity: 1, scale: 1, svgOrigin: "${CX} ${CY}", duration: 0.2, ease: "power2.out" }, 14.6);

  // ---------- s6 · ivory node graph: a dot draws a dotted line from card to card and the camera rides along; each card fills with gold like liquid
  const s6 = ${T.s6};
  const ride = (id, t0, d) => {
    const p = { v: 0 };
    tl.fromTo("#" + id, { strokeDashoffset: 1000 }, { strokeDashoffset: 0, duration: d, ease: "power1.inOut", immediateRender: false }, t0);
    tl.to(p, { v: 1, duration: d, ease: "power1.inOut", onUpdate: () => {
      const el = document.getElementById(id), len = el.getTotalLength(), pt = el.getPointAtLength(p.v * len);
      const dot = document.getElementById("s6-dot"); dot.setAttribute("cx", pt.x); dot.setAttribute("cy", pt.y);
    } }, t0);
  };
  const fillFlash = (i, at) => {
    tl.fromTo("#s6-p" + i + " .gd", { opacity: 1, clipPath: "inset(0 0 0 100%)" }, { clipPath: "inset(0 0 0 0%)", duration: 0.18, ease: "power2.out", immediateRender: false }, at);
    tl.to("#s6-p" + i + " .gd", { opacity: 0, duration: 0.22, ease: "power1.in" }, at + 0.26);
  };
  tl.fromTo("#s6-p0", { scaleX: 0.4, scaleY: 0.34 }, { scaleX: 1, scaleY: 1, duration: 0.25, ease: "expo.out" }, s6);
  tl.fromTo("#s6-p0 .gd", { opacity: 1, clipPath: "inset(0 0 0 0%)" }, { opacity: 0, duration: 0.25 }, s6 + 0.05);
  ${WORDS6.map((_, i) => `tl.set("#f${i}", { fontWeight: 800 }, ${(15.45 + i * 0.25).toFixed(2)}); tl.set("#f${i}", { fontWeight: 400 }, ${(15.7 + i * 0.25).toFixed(2)});`).join(" ")}
  tl.fromTo("#foot", { opacity: 0 }, { opacity: 1, duration: 0.3 }, s6 + 0.1);
  ride("s6-l1", 15.55, 1.35);
  fillFlash(0, 16.98);
  tl.fromTo("#s6-arrow", { opacity: 0, x: -10 }, { opacity: 1, x: 0, duration: 0.15 }, 17.3);
  tl.to("#s6-world", { x: ${540 - W_PILLS[1][1]}, y: ${958 - W_PILLS[1][2]}, duration: 0.8, ease: "power2.inOut" }, 17.35);
  ride("s6-l2", 17.4, 0.85);
  fillFlash(1, 18.55);
  tl.to("#s6-world", { x: ${540 - W_PILLS[2][1]}, y: ${958 - W_PILLS[2][2]}, duration: 1.0, ease: "power2.inOut" }, 19.3);
  ride("s6-l3", 19.25, 1.0);
  fillFlash(2, 20.78);
  ride("s6-l4", 21.2, 1.0);
  tl.to("#s6-world", { x: ${540 - W_PILLS[2][1] - 560}, duration: 0.7, ease: "power2.in" }, 21.6);
  tl.fromTo("#s6-wipe", { x: 0 }, { x: 3000, duration: 0.42, ease: "power1.in" }, 22.0);
  tl.set("#foot", { color: "${C.ivory}" }, ${T.s7});

  // ---------- s7 · Connected: the dot slides on, swings up a gold arc to the corner, the outline draws itself from there, the word types in
  tl.fromTo("#s7-dot", { attr: { cx: 330 } }, { attr: { cx: 560 }, duration: 0.5, ease: "sine.out" }, 22.4);
  tl.fromTo("#s7-l", { attr: { d: "M 250 ${CY} L 330 ${CY}" } }, { attr: { d: "M 330 ${CY} L 560 ${CY}" }, duration: 0.5, ease: "sine.out" }, 22.4);
  tl.fromTo("#s7-arc", { strokeDashoffset: 100 }, { strokeDashoffset: 0, duration: 0.28, ease: "power2.out" }, 22.9);
  tl.to("#s7-dot", { attr: { cx: 790, cy: ${CY - 95} }, duration: 0.28, ease: "power2.out" }, 22.9);
  tl.to("#s7-l, #s7-arc, #s7-dot", { opacity: 0, duration: 0.18 }, 23.22);
  tl.fromTo("#s7-p, #s7-pglow", { strokeDashoffset: 100 }, { strokeDashoffset: 0, duration: 0.6, ease: "power2.inOut" }, 23.18);
  tl.fromTo("#s7-t", { clipPath: "inset(-30% 0 -30% 100%)" }, { clipPath: "inset(-30% 0 -30% 0%)", duration: 0.5, ease: "steps(6)" }, 23.55);
  tl.to("#s7-w", { scale: 1.05, duration: 0.9, ease: "none" }, 24.05);
  tl.to("#s7-w", { rotationX: 55, y: 260, x: -160, scale: 0.78, opacity: 0, filter: "blur(10px)", transformPerspective: 1100, duration: 0.42, ease: "power2.in" }, 24.95);

  // ---------- s8 · Thought in motion: light blobs sweep right-to-left and write the words, sweep back and wipe them, gather, burst
  const s8 = ${T.s8};
  tl.fromTo("#s8-b0, #s8-b1, #s8-b2", { scale: 0, opacity: 0, x: 160, y: -90 }, { scale: 0.6, opacity: 0.8, duration: 0.4, stagger: 0.08, ease: "power2.out" }, s8 + 0.05);
  ${[[0, -40, 30], [1, 20, -30], [2, 40, 40]].map(([i, ox, oy]) => `tl.to("#s8-b${i}", { x: ${300 + ox}, y: ${oy}, scale: 1, duration: 0.45, ease: "power2.inOut" }, ${(T.s8 + 0.4).toFixed(2)});
  tl.to("#s8-b${i}", { x: ${-300 + ox}, y: ${-oy}, duration: 1.8, ease: "sine.inOut" }, ${(T.s8 + 0.85).toFixed(2)});
  tl.to("#s8-b${i}", { x: ${300 - ox}, y: ${oy * 1.5}, duration: 0.9, ease: "sine.inOut" }, 28.0);
  tl.to("#s8-b${i}", { x: ${ox * 0.4}, y: ${oy * 0.4}, scale: 0.8, duration: 0.6, ease: "sine.inOut" }, 28.9);
  tl.to("#s8-b${i}", { x: ${[-420, 380, 60][i]}, y: ${[-260, -200, 420][i]}, scale: 0.3, opacity: 0, duration: 0.35, ease: "power3.out" }, 29.5);`).join("\n  ")}
  tl.fromTo("#s8-t", { clipPath: "inset(-30% 0 -30% 100%)" }, { clipPath: "inset(-30% 0 -30% 0%)", duration: 1.8, ease: "sine.inOut" }, ${(T.s8 + 0.85).toFixed(2)});
  tl.to("#s8-t", { clipPath: "inset(-30% 100% -30% 0%)", duration: 0.9, ease: "sine.inOut" }, 28.0);

  // ---------- s9 · HOSSO end card out of the burst
  tl.fromTo("#s9-flash", { scale: 0.2, opacity: 1 }, { scale: 1.6, opacity: 0, duration: 0.6, ease: "power2.out" }, ${T.s9});
  tl.fromTo("#logo", { opacity: 0, scale: 0.86, filter: "blur(12px)" }, { opacity: 1, scale: 1, filter: "blur(0px)", duration: 0.45, ease: "power2.out" }, ${T.s9 + 0.05});
  tl.fromTo("#url", { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.35, ease: "power2.out" }, ${T.s9 + 0.35});

  window.__timelines = window.__timelines || {};
  window.__timelines["main"] = tl;
</script>
</body></html>
`;

fs.mkdirSync(path.join(OUT, "assets/fonts"), { recursive: true });
for (const f of ["package.json", "hyperframes.json", "meta.json"]) fs.copyFileSync(path.join(STUDIO, "jobs/re-exact/project", f), path.join(OUT, f));
fs.cpSync(path.join(STUDIO, "jobs/re-exact/project/assets/sfx"), path.join(OUT, "assets/sfx"), { recursive: true });
fs.cpSync(path.join(HERE, "pro"), path.join(OUT, "assets/sfx/pro"), { recursive: true });
if (OUT !== path.join(HERE, "project")) fs.copyFileSync(music, path.join(OUT, "assets/music.mp3"));
fs.copyFileSync(path.join(STUDIO, "base/assets/fonts/cairo-arabic.woff2"), path.join(OUT, "assets/fonts/cairo-arabic.woff2"));
fs.copyFileSync(path.join(STUDIO, "base/assets/brand/hosso-light.png"), path.join(OUT, "assets/hosso-light.png"));
if (VOICE) fs.cpSync(path.join(HERE, "vo"), path.join(OUT, "assets/vo"), { recursive: true });
fs.writeFileSync(path.join(OUT, "index.html"), html);
console.log("wrote", path.relative(HERE, OUT) + "/index.html");
