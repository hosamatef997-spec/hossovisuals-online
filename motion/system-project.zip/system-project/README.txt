مشروع ريل «بنظام واضح» — HOSSO | VISUALS (hossovisuals.online/motion)

index.html  = الفيديو كله (HyperFrames: HTML بيتحول لفيديو)
gen.mjs     = السكريبت اللي بيكتب index.html (الأرقام والتوقيتات والألوان كلها هنا)

تشغيله:
1) ثبّت Node.js و ffmpeg
2) في الفولدر ده:  npx hyperframes preview      (تشوفه في المتصفح)
3) الرندر 4K ببلور حركة:  npx hyperframes render -o reel.mp4 --resolution portrait-4k --fps 60

المزيكا والأصوات وصوتي مش جوه الملف. حط مزيكتك في assets/music.mp3، أو شيل سطور الـ audio.
غيّر الكلام والألوان من gen.mjs (const L = … و const C = …).
