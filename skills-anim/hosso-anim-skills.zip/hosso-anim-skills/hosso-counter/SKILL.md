---
name: hosso-counter
description: Makes a 9:16 HOSSO-style video (HyperFrames, navy + champagne) of a big number counting up to a target with a filling segment bar. Use when the user types /hosso-counter or asks for a counter / «رقم بيعد» animation.
---

# /hosso-counter — رقم بيعدّ لحد هدفك ويخبط

One prompt, one video: a 9:16 clip (1080×1920, 30 fps, 5 s) in the HOSSO look — navy `#0F1B33`, champagne `#D8B878`, ivory `#F4EFE6`, Arabic in **Beiruti**, Latin in **Bricolage Grotesque**.
What it shows: a big champagne number counts up from 0 to your number, a bar of segments fills with it, the number lands with a bump and a glow, and the label's key word gets the block.
It is rendered on the user's own computer with HyperFrames (HTML → MP4). Built on the HOSSO studio block «odometer / counter».

Example: `/hosso-counter 1,440 · دقيقة في اليوم · Claude شغال عندي`

## What you need from the user
The words after the command. Map them onto the fields below; anything they did not give keeps its default. If the main words are missing, ask once, in the user's language, then go on.

| Field | What goes there | Default |
| --- | --- | --- |
| `{{KICKER}}` | small line in the pill above the number | `<bdi class="lat">Claude</bdi> شغال عندي` |
| `{{TO}}` | the target number, digits only, commas allowed (1,440) | `1,440` |
| `{{LABEL}}` | what the number counts, with the ONE key word in the block | `<span>دقيقة في</span> <span class="blk">اليوم</span>` |
| `{{SEGMENTS}}` | how many segments the bar has (8–30) | `24` |
| `{{HANDLE}}` | the user's handle at the bottom (or empty) | `@hossovisuals.ai` |

Text rules (they keep the look right):
- Put every Latin word or run (`Claude Code`, `reel.mp4`, `3D`) inside `<bdi class="lat">…</bdi>` when it sits in an Arabic line, so it keeps its order and gets Bricolage.
- Only ONE word (or two) per card goes in the champagne block: `<span class="blk">…</span>`. Keep the block where the template has it.
- In a line that holds the block, put the other words in their own `<span>…</span>` too (as in the defaults), or the contrast check reads the block as their background.
- Escape `<`, `>` and `&` in the user's words. Keep titles short (each title line ≤ 14 Arabic letters at this size) so nothing is cut.

## Do this
1. Make a folder `hosso-counter-<short-slug>/` in the current directory.
2. Copy the three font files from this skill's `fonts/` folder (`beiruti-var-arabic.woff2`, `beiruti-var-latin.woff2`, `bricolage-grotesque-var-latin.woff2`) into `<folder>/assets/fonts/`, same names. If the user gave an image for an icon, copy it into `<folder>/assets/`.
3. Write `<folder>/index.html`: the template below, with every `{{…}}` replaced by the field value. Change nothing else.
4. Write `<folder>/hyperframes.json`: `{"$schema": "https://hyperframes.heygen.com/schema/hyperframes.json", "paths": {"blocks": "compositions", "components": "compositions/components", "assets": "assets"}, "media": {"autoProxy": true}}` and `<folder>/package.json`: `{"name": "hosso-counter", "private": true, "type": "module"}`.
5. In the folder run `npx --yes hyperframes@0.8.221 check` and fix every error it reports, then `npx --yes hyperframes@0.8.221 render --output hosso-counter.mp4`.
6. Look at one frame near the end (`ffmpeg -ss 3 -i hosso-counter.mp4 -frames:v 1 check.jpg`): no word cut, nothing on top of something else. Then give the user the path of the MP4.

Keep the colours, fonts and timing as they are unless the user asks. The video has no sound; add music in your editor.
Needs: Node.js 22+, FFmpeg, and internet on the first run (npx downloads HyperFrames and its browser; the template loads GSAP from jsDelivr).

## Template (`index.html`)
```html
<!doctype html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1080, height=1920" />
<title>hosso-counter</title>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js" integrity="sha384-sG0Hv1tP1lZCk9KQmrIbY/XNwi+OY84GQqhMscbnsoBFqAz8KNCil1kvfL3Hbbk2" crossorigin="anonymous"></script>
<style>
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-arabic.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0600-06FF, U+0750-077F, U+0870-08FF, U+200C-200E, U+2010-2011, U+FB50-FDFF, U+FE70-FEFC; }
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-latin.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0000-00FF, U+2000-206F, U+20AC, U+2122, U+2212; }
@font-face { font-family: "Bricolage Grotesque"; src: url("assets/fonts/bricolage-grotesque-var-latin.woff2") format("woff2"); font-weight: 200 800; unicode-range: U+0000-00FF, U+2000-206F, U+2190-21FF, U+2212; }
:root { --navy: #0F1B33; --deep: #08101F; --slate: #5A6E93; --champ: #D8B878; --ivory: #F4EFE6; }
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 1080px; height: 1920px; overflow: hidden; background: #08101F; }
#root { position: relative; width: 1080px; height: 1920px; overflow: hidden; font-family: "Beiruti", sans-serif; color: #F4EFE6; }
#bg { position: absolute; inset: 0; background: radial-gradient(ellipse 70% 40% at 50% 42%, rgba(90,110,147,.42), transparent 72%), linear-gradient(170deg, #142544 0%, #0F1B33 55%, #08101F 100%); }
#grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(244,239,230,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(244,239,230,.04) 1px, transparent 1px);
  background-size: 67.5px 67.5px; -webkit-mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); }
#stage { position: absolute; inset: 0; }
.lat { font-family: "Bricolage Grotesque", sans-serif; font-weight: 700; letter-spacing: -.01em; unicode-bidi: isolate; }
.ttl { position: absolute; left: 80px; right: 80px; text-align: center; direction: rtl; font-weight: 800; line-height: 1.12; color: #F4EFE6; text-shadow: 0 6px 30px rgba(4,9,20,.4); }
.blk { position: relative; display: inline-block; color: #0F1B33; background-color: #D8B878; border-radius: .2em; padding: .03em .2em .08em; margin: 0 .04em; line-height: 1.02; --wipe: 100%; text-shadow: none;
  clip-path: inset(0 0 0 calc(100% - var(--wipe)) round .2em); }
.handle { position: absolute; left: 0; right: 0; top: 1500px; text-align: center; font: 600 30px "Bricolage Grotesque", sans-serif; letter-spacing: .14em; color: rgba(244,239,230,.5); direction: ltr; }
#grain { position: absolute; inset: 0; opacity: .05; pointer-events: none; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>"); }
#kick { position: absolute; left: 0; right: 0; top: 400px; text-align: center; }
#kick span { display: inline-block; padding: 12px 40px 16px; border-radius: 999px; font: 700 48px "Beiruti", sans-serif; direction: rtl; color: rgba(244,239,230,.9);
  background: rgba(8,16,31,.45); box-shadow: inset 0 0 0 2px rgba(216,184,120,.6); }
#glow { position: absolute; left: 140px; right: 140px; top: 560px; height: 360px; border-radius: 50%; background: radial-gradient(closest-side, rgba(216,184,120,.38), transparent 75%); opacity: .3; }
#num { position: absolute; left: 0; right: 0; top: 560px; text-align: center; font: 800 300px/1.1 "Bricolage Grotesque", sans-serif; color: #D8B878; direction: ltr;
  letter-spacing: -.03em; font-variant-numeric: tabular-nums; text-shadow: 0 10px 40px rgba(0,0,0,.45); }
#bar { position: absolute; left: 140px; width: 800px; top: 1130px; height: 64px; padding: 12px; border-radius: 18px; display: flex; gap: 6px; direction: ltr;
  background: rgba(8,16,31,.55); box-shadow: inset 0 0 0 1.5px rgba(216,184,120,.35); }
#bar i { flex: 1; border-radius: 5px; background: rgba(244,239,230,.1); }
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="5" data-width="1080" data-height="1920">
  <div id="bg" class="clip" data-start="0" data-duration="5" data-track-index="0"><div id="grid"></div></div>
  <div id="stage" class="clip" data-start="0" data-duration="5" data-track-index="1">
<div id="kick"><span>{{KICKER}}</span></div>
    <div id="glow"></div>
    <div id="num" data-to="{{TO}}">0</div>
    <div class="ttl" id="lab" style="top:940px;font-size:96px">{{LABEL}}</div>
    <div id="bar" data-n="{{SEGMENTS}}"></div>
    <div class="handle">{{HANDLE}}</div>
  </div>
  <div id="grain" class="clip" data-start="0" data-duration="5" data-track-index="2"></div>
</div>
<script>
  var tl = gsap.timeline({ paused: true });
  // a line of text rises out of a soft blur
  function rise(sel, at) { tl.fromTo(sel, { y: 36, opacity: 0, filter: "blur(10px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.5, ease: "expo.out" }, at); }
  // the champagne block behind the key word wipes in from the right (Arabic reads right to left)
  function wipe(sel, at) { if (document.querySelector(sel)) tl.fromTo(sel, { "--wipe": "0%" }, { "--wipe": "100%", duration: 0.42, ease: "power2.inOut" }, at); }
var numEl = document.getElementById("num"), barEl = document.getElementById("bar");
  var target = parseFloat(String(numEl.getAttribute("data-to")).replace(/,/g, "")) || 0;
  var n = Math.max(4, Math.min(40, parseInt(barEl.getAttribute("data-n"), 10) || 24));
  for (var i = 0; i < n; i++) barEl.appendChild(document.createElement("i"));
  var c = { v: 0 }, T0 = 0.1, T = 1.05;
  tl.fromTo("#kick span", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.4, ease: "expo.out" }, 0);
  tl.fromTo("#num", { opacity: 0, scale: 0.85 }, { opacity: 1, scale: 1, duration: 0.4, ease: "back.out(1.6)" }, 0.05);
  tl.to(c, { v: target, duration: T, ease: "power2.out", onUpdate: function () { numEl.textContent = Math.round(c.v).toLocaleString("en-US"); } }, T0);
  rise("#lab", 0.3);
  tl.fromTo("#bar", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.35, ease: "expo.out" }, 0.25);
  // each segment lights when the count passes it (same power2.out curve: x = 1 - sqrt(1 - p))
  var segs = barEl.querySelectorAll("i");
  for (var k = 0; k < segs.length; k++) tl.set(segs[k], { backgroundColor: "#D8B878" }, T0 + T * (1 - Math.sqrt(1 - (k + 1) / segs.length)));
  tl.fromTo("#num", { scale: 1 }, { scale: 1.08, duration: 0.14, yoyo: true, repeat: 1, ease: "power2.out", immediateRender: false }, T0 + T);
  tl.fromTo("#glow", { opacity: 0.3 }, { opacity: 1, duration: 0.2, yoyo: true, repeat: 1, immediateRender: false }, T0 + T);
  wipe("#lab .blk", T0 + T + 0.05);
  tl.to("#glow", { opacity: 0.6, duration: 0.9, ease: "sine.inOut", yoyo: true, repeat: 3 }, 1.8);
  window.__timelines = window.__timelines || {};
  window.__timelines["main"] = tl;
</script>
</body>
</html>
```
