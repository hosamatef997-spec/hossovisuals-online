---
name: hosso-radial
description: Makes a 9:16 HOSSO-style video (HyperFrames, navy + champagne) of one centre icon with 4–8 chips bursting round it on dashed spokes, one chip lighting up. Use when the user types /hosso-radial or asks for a radial / «كل حاجة حوالين أيقونة» animation.
---

# /hosso-radial — أيقونة في النص وحواليها كل حاجة

One prompt, one video: a 9:16 clip (1080×1920, 30 fps, 5 s) in the HOSSO look — navy `#0F1B33`, champagne `#D8B878`, ivory `#F4EFE6`, Arabic in **Beiruti**, Latin in **Bricolage Grotesque**.
What it shows: a centre tile pops in, then chips burst round it one by one, each with its own dashed spoke, and one chip lights up champagne while a ring pulses out of the centre.
It is rendered on the user's own computer with HyperFrames (HTML → MP4). Built on the HOSSO studio block «radial».

Example: `/hosso-radial Claude بيعمل كل ده · Reels, Carousels, Stories, Captions, Replies, Pages`

## What you need from the user
The words after the command. Map them onto the fields below; anything they did not give keeps its default. If the main words are missing, ask once, in the user's language, then go on.

| Field | What goes there | Default |
| --- | --- | --- |
| `{{TITLE}}` | title, with the ONE key word (or two) in the block | `<bdi class="lat">Claude</bdi> <span>بيعمل</span> <span class="blk">كل ده</span>` |
| `{{CENTER}}` | inside of the centre tile: an inline SVG, an <img src="assets/c.png">, or one big letter in <b> | the Claude symbol SVG (orange #D97757) |
| `{{CENTER_BG}}` | CSS background of the centre tile | `#F4EFE6` |
| `{{CHIPS}}` | 4 to 8 chips, each written as <div class="chip"><span>Word</span></div> (short words, any language) | 6 chips: Reels, Carousels, Stories, Captions, Replies, Pages |
| `{{MARK}}` | the number of the chip that lights up champagne (1 = the first chip, at the top) | `1` |
| `{{HANDLE}}` | the user's handle at the bottom (or empty) | `@hossovisuals.ai` |

Text rules (they keep the look right):
- Put every Latin word or run (`Claude Code`, `reel.mp4`, `3D`) inside `<bdi class="lat">…</bdi>` when it sits in an Arabic line, so it keeps its order and gets Bricolage.
- Only ONE word (or two) per card goes in the champagne block: `<span class="blk">…</span>`. Keep the block where the template has it.
- In a line that holds the block, put the other words in their own `<span>…</span>` too (as in the defaults), or the contrast check reads the block as their background.
- Escape `<`, `>` and `&` in the user's words. Keep titles short (each title line ≤ 14 Arabic letters at this size) so nothing is cut.

## Do this
1. Make a folder `hosso-radial-<short-slug>/` in the current directory.
2. Copy the three font files from this skill's `fonts/` folder (`beiruti-var-arabic.woff2`, `beiruti-var-latin.woff2`, `bricolage-grotesque-var-latin.woff2`) into `<folder>/assets/fonts/`, same names. If the user gave an image for an icon, copy it into `<folder>/assets/`.
3. Write `<folder>/index.html`: the template below, with every `{{…}}` replaced by the field value. Change nothing else.
4. Write `<folder>/hyperframes.json`: `{"$schema": "https://hyperframes.heygen.com/schema/hyperframes.json", "paths": {"blocks": "compositions", "components": "compositions/components", "assets": "assets"}, "media": {"autoProxy": true}}` and `<folder>/package.json`: `{"name": "hosso-radial", "private": true, "type": "module"}`.
5. In the folder run `npx --yes hyperframes@0.8.221 check` and fix every error it reports, then `npx --yes hyperframes@0.8.221 render --output hosso-radial.mp4`.
6. Look at one frame near the end (`ffmpeg -ss 3 -i hosso-radial.mp4 -frames:v 1 check.jpg`): no word cut, nothing on top of something else. Then give the user the path of the MP4.

Keep the colours, fonts and timing as they are unless the user asks. The video has no sound; add music in your editor.
Needs: Node.js 22+, FFmpeg, and internet on the first run (npx downloads HyperFrames and its browser; the template loads GSAP from jsDelivr).

## Template (`index.html`)
```html
<!doctype html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1080, height=1920" />
<title>hosso-radial</title>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js" integrity="sha384-sG0Hv1tP1lZCk9KQmrIbY/XNwi+OY84GQqhMscbnsoBFqAz8KNCil1kvfL3Hbbk2" crossorigin="anonymous"></script>
<style>
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-arabic.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0600-06FF, U+0750-077F, U+0870-08FF, U+200C-200E, U+2010-2011, U+FB50-FDFF, U+FE70-FEFC; }
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-latin.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0000-00FF, U+2000-206F, U+20AC, U+2122, U+2212; }
@font-face { font-family: "Bricolage Grotesque"; src: url("assets/fonts/bricolage-grotesque-var-latin.woff2") format("woff2"); font-weight: 200 800; unicode-range: U+0000-00FF, U+2000-206F, U+2190-21FF, U+2212; }
:root { --navy: #0F1B33; --deep: #08101F; --slate: #5A6E93; --champ: #D8B878; --ivory: #F4EFE6; }
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 1080px; height: 1920px; overflow: hidden; background: #08101F; }
#root { position: relative; width: 1080px; height: 1920px; overflow: hidden; font-family: "Beiruti", sans-serif; color: #F4EFE6; }
#bg { position: absolute; inset: 0; background: radial-gradient(ellipse 70% 40% at 50% 42%, rgba(90,110,147,.42), transparent 72%), linear-gradient(170deg, #142544 0%, #0F1B33 55%, #08101F 100%); }
#grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(244,239,230,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(244,239,230,.04) 1px, transparent 1px);
  background-size: 67.5px 67.5px; -webkit-mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); }
#stage { position: absolute; inset: 0; }
.lat { font-family: "Bricolage Grotesque", sans-serif; font-weight: 700; letter-spacing: -.01em; unicode-bidi: isolate; }
.ttl { position: absolute; left: 80px; right: 80px; text-align: center; direction: rtl; font-weight: 800; line-height: 1.12; color: #F4EFE6; text-shadow: 0 6px 30px rgba(4,9,20,.4); }
.blk { position: relative; display: inline-block; color: #0F1B33; background-color: #D8B878; border-radius: .2em; padding: .03em .2em .08em; margin: 0 .04em; line-height: 1.02; --wipe: 100%; text-shadow: none;
  clip-path: inset(0 0 0 calc(100% - var(--wipe)) round .2em); }
.handle { position: absolute; left: 0; right: 0; top: 1500px; text-align: center; font: 600 30px "Bricolage Grotesque", sans-serif; letter-spacing: .14em; color: rgba(244,239,230,.5); direction: ltr; }
#grain { position: absolute; inset: 0; opacity: .05; pointer-events: none; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>"); }
#sp { position: absolute; left: 0; top: 0; overflow: visible; }
#sp line { stroke: rgba(216,184,120,.55); stroke-width: 4; stroke-dasharray: 0.02 0.03; }
#ctr { position: absolute; left: 420px; top: 880px; width: 240px; height: 240px; border-radius: 56px; display: flex; align-items: center; justify-content: center;
  box-shadow: 0 30px 60px rgba(0,0,0,.45), 0 0 0 2px rgba(244,239,230,.14); }
#ctr svg, #ctr img { width: 62%; height: 62%; object-fit: contain; display: block; }
#ctr b { font: 800 130px "Bricolage Grotesque", sans-serif; color: #0F1B33; }
#ring { position: absolute; left: 390px; top: 850px; width: 300px; height: 300px; border-radius: 70px; box-shadow: 0 0 0 4px #D8B878; opacity: 0; }
.chip { position: absolute; transform: translate(-50%, -50%); }
.chip span { display: inline-block; padding: 16px 36px 20px; border-radius: 999px; font: 700 46px "Bricolage Grotesque", sans-serif; white-space: nowrap; color: #F4EFE6; direction: ltr;
  background: rgba(23,36,64,.94); box-shadow: inset 0 0 0 2px rgba(216,184,120,.55), 0 14px 30px rgba(0,0,0,.4); }
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="5" data-width="1080" data-height="1920">
  <div id="bg" class="clip" data-start="0" data-duration="5" data-track-index="0"><div id="grid"></div></div>
  <div id="stage" class="clip" data-start="0" data-duration="5" data-track-index="1">
<div class="ttl" id="t1" style="top:300px;font-size:116px">{{TITLE}}</div>
    <svg id="sp" width="1080" height="1920" viewBox="0 0 1080 1920"></svg>
    <div id="ring"></div>
    <div id="ctr" style="background:{{CENTER_BG}}">{{CENTER}}</div>
    <div id="chips" data-mark="{{MARK}}">{{CHIPS}}</div>
    <div class="handle">{{HANDLE}}</div>
  </div>
  <div id="grain" class="clip" data-start="0" data-duration="5" data-track-index="2"></div>
</div>
<script>
  var tl = gsap.timeline({ paused: true });
  // a line of text rises out of a soft blur
  function rise(sel, at) { tl.fromTo(sel, { y: 36, opacity: 0, filter: "blur(10px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.5, ease: "expo.out" }, at); }
  // the champagne block behind the key word wipes in from the right (Arabic reads right to left)
  function wipe(sel, at) { if (document.querySelector(sel)) tl.fromTo(sel, { "--wipe": "0%" }, { "--wipe": "100%", duration: 0.42, ease: "power2.inOut" }, at); }
// lay the chips on an ellipse round the centre (layout only), first chip at the top, then clockwise
  var CX = 540, CY = 1000, R = 370, chips = document.querySelectorAll("#chips .chip"), svg = document.getElementById("sp"), NS = "http://www.w3.org/2000/svg";
  for (var k = 0; k < chips.length; k++) {
    var a = -Math.PI / 2 + (k / chips.length) * Math.PI * 2, x = CX + R * Math.cos(a), y = CY + R * 0.9 * Math.sin(a);
    chips[k].style.left = x.toFixed(0) + "px"; chips[k].style.top = y.toFixed(0) + "px";
    var ln = document.createElementNS(NS, "line");
    ln.setAttribute("x1", CX); ln.setAttribute("y1", CY); ln.setAttribute("x2", (CX + (R - 90) * Math.cos(a)).toFixed(0)); ln.setAttribute("y2", (CY + (R - 90) * 0.9 * Math.sin(a)).toFixed(0));
    ln.setAttribute("pathLength", "1"); ln.style.strokeDashoffset = "1"; svg.appendChild(ln);
  }
  rise("#t1", 0);
  tl.fromTo("#ctr", { scale: 0.6, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.45, ease: "back.out(2)" }, 0.05);
  var lines = svg.querySelectorAll("line");
  for (var j = 0; j < chips.length; j++) {
    var t = 0.3 + j * 0.12;
    tl.fromTo(lines[j], { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 0.22, ease: "none" }, t - 0.08);
    tl.fromTo(chips[j].querySelector("span"), { scale: 0, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.32, ease: "back.out(2.6)" }, t);
  }
  var m = Math.max(1, Math.min(chips.length, parseInt(document.getElementById("chips").getAttribute("data-mark"), 10) || 1)) - 1, tm = 0.3 + chips.length * 0.12 + 0.06;
  tl.to(chips[m].querySelector("span"), { backgroundColor: "#D8B878", color: "#0F1B33", scale: 1.14, duration: 0.24, ease: "back.out(2)" }, tm);
  wipe("#t1 .blk", tm - 0.03);
  function ring(at) { tl.fromTo("#ring", { opacity: 0.9, scale: 0.8 }, { opacity: 0, scale: 1.7, duration: 0.7, ease: "power2.out", immediateRender: false }, at); }
  ring(tm); ring(2.4); ring(3.7);
  tl.to("#ctr", { y: -12, duration: 1, ease: "sine.inOut", yoyo: true, repeat: 3 }, 1.4);
  window.__timelines = window.__timelines || {};
  window.__timelines["main"] = tl;
</script>
</body>
</html>
```
