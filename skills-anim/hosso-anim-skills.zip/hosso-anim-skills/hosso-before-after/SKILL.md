---
name: hosso-before-after
description: Makes a 9:16 HOSSO-style before/after video (HyperFrames, navy + champagne): a cursor drags a slider that wipes the old version into the new one. Use when the user types /hosso-before-after or asks for a «قبل وبعد» / before-after slider animation.
---

# /hosso-before-after — سلايدر بيمسح القديم ويظهر الجديد

One prompt, one video: a 9:16 clip (1080×1920, 30 fps, 5 s) in the HOSSO look — navy `#0F1B33`, champagne `#D8B878`, ivory `#F4EFE6`, Arabic in **Beiruti**, Latin in **Bricolage Grotesque**.
What it shows: a glass frame shows the «before» panel, a cursor grabs the champagne knob and drags the line across, wiping the «after» panel in from the right, then its three checks pop.
It is rendered on the user's own computer with HyperFrames (HTML → MP4). Built on the HOSSO studio block «beforeafter».

Example: `/hosso-before-after قبل: اكتبلي بوست · بعد: بوست إنستجرام، لأصحاب البراندات، 3 سطور بالمصري`

## What you need from the user
The words after the command. Map them onto the fields below; anything they did not give keeps its default. If the main words are missing, ask once, in the user's language, then go on.

| Field | What goes there | Default |
| --- | --- | --- |
| `{{TITLE}}` | title above the frame, with the ONE key word in the block | `<span>قبل و</span><span class="blk">بعد</span>` |
| `{{BEFORE_LABEL}}` | small label of the old side | `قبل` |
| `{{BEFORE_HEAD}}` | headline of the old side | `طلب مبهم` |
| `{{BEFORE_LINE}}` | the old version in one short line | `اكتبلي بوست` |
| `{{AFTER_LABEL}}` | small label of the new side | `بعد` |
| `{{AFTER_HEAD}}` | headline of the new side, with one word in the block | `<span>طلب</span> <span class="blk">كامل</span>` |
| `{{AFTER_1}}` | new version, point 1 | `بوست إنستجرام` |
| `{{AFTER_2}}` | new version, point 2 | `لأصحاب البراندات` |
| `{{AFTER_3}}` | new version, point 3 | `3 سطور بالمصري` |
| `{{HANDLE}}` | the user's handle at the bottom (or empty) | `@hossovisuals.ai` |

Text rules (they keep the look right):
- Put every Latin word or run (`Claude Code`, `reel.mp4`, `3D`) inside `<bdi class="lat">…</bdi>` when it sits in an Arabic line, so it keeps its order and gets Bricolage.
- Only ONE word (or two) per card goes in the champagne block: `<span class="blk">…</span>`. Keep the block where the template has it.
- In a line that holds the block, put the other words in their own `<span>…</span>` too (as in the defaults), or the contrast check reads the block as their background.
- Escape `<`, `>` and `&` in the user's words. Keep titles short (each title line ≤ 14 Arabic letters at this size) so nothing is cut.

## Do this
1. Make a folder `hosso-before-after-<short-slug>/` in the current directory.
2. Copy the three font files from this skill's `fonts/` folder (`beiruti-var-arabic.woff2`, `beiruti-var-latin.woff2`, `bricolage-grotesque-var-latin.woff2`) into `<folder>/assets/fonts/`, same names. If the user gave an image for an icon, copy it into `<folder>/assets/`.
3. Write `<folder>/index.html`: the template below, with every `{{…}}` replaced by the field value. Change nothing else.
4. Write `<folder>/hyperframes.json`: `{"$schema": "https://hyperframes.heygen.com/schema/hyperframes.json", "paths": {"blocks": "compositions", "components": "compositions/components", "assets": "assets"}, "media": {"autoProxy": true}}` and `<folder>/package.json`: `{"name": "hosso-before-after", "private": true, "type": "module"}`.
5. In the folder run `npx --yes hyperframes@0.8.221 check` and fix every error it reports, then `npx --yes hyperframes@0.8.221 render --output hosso-before-after.mp4`.
6. Look at one frame near the end (`ffmpeg -ss 3 -i hosso-before-after.mp4 -frames:v 1 check.jpg`): no word cut, nothing on top of something else. Then give the user the path of the MP4.

Keep the colours, fonts and timing as they are unless the user asks. The video has no sound; add music in your editor.
Needs: Node.js 22+, FFmpeg, and internet on the first run (npx downloads HyperFrames and its browser; the template loads GSAP from jsDelivr).

## Template (`index.html`)
```html
<!doctype html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1080, height=1920" />
<title>hosso-before-after</title>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js" integrity="sha384-sG0Hv1tP1lZCk9KQmrIbY/XNwi+OY84GQqhMscbnsoBFqAz8KNCil1kvfL3Hbbk2" crossorigin="anonymous"></script>
<style>
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-arabic.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0600-06FF, U+0750-077F, U+0870-08FF, U+200C-200E, U+2010-2011, U+FB50-FDFF, U+FE70-FEFC; }
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-latin.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0000-00FF, U+2000-206F, U+20AC, U+2122, U+2212; }
@font-face { font-family: "Bricolage Grotesque"; src: url("assets/fonts/bricolage-grotesque-var-latin.woff2") format("woff2"); font-weight: 200 800; unicode-range: U+0000-00FF, U+2000-206F, U+2190-21FF, U+2212; }
:root { --navy: #0F1B33; --deep: #08101F; --slate: #5A6E93; --champ: #D8B878; --ivory: #F4EFE6; }
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 1080px; height: 1920px; overflow: hidden; background: #08101F; }
#root { position: relative; width: 1080px; height: 1920px; overflow: hidden; font-family: "Beiruti", sans-serif; color: #F4EFE6; }
#bg { position: absolute; inset: 0; background: radial-gradient(ellipse 70% 40% at 50% 42%, rgba(90,110,147,.42), transparent 72%), linear-gradient(170deg, #142544 0%, #0F1B33 55%, #08101F 100%); }
#grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(244,239,230,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(244,239,230,.04) 1px, transparent 1px);
  background-size: 67.5px 67.5px; -webkit-mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); }
#stage { position: absolute; inset: 0; }
.lat { font-family: "Bricolage Grotesque", sans-serif; font-weight: 700; letter-spacing: -.01em; unicode-bidi: isolate; }
.ttl { position: absolute; left: 80px; right: 80px; text-align: center; direction: rtl; font-weight: 800; line-height: 1.12; color: #F4EFE6; text-shadow: 0 6px 30px rgba(4,9,20,.4); }
.blk { position: relative; display: inline-block; color: #0F1B33; background-color: #D8B878; border-radius: .2em; padding: .03em .2em .08em; margin: 0 .04em; line-height: 1.02; --wipe: 100%; text-shadow: none;
  clip-path: inset(0 0 0 calc(100% - var(--wipe)) round .2em); }
.handle { position: absolute; left: 0; right: 0; top: 1500px; text-align: center; font: 600 30px "Bricolage Grotesque", sans-serif; letter-spacing: .14em; color: rgba(244,239,230,.5); direction: ltr; }
#grain { position: absolute; inset: 0; opacity: .05; pointer-events: none; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>"); }
#fr { position: absolute; left: 90px; top: 540px; width: 900px; height: 720px; border-radius: 40px; overflow: hidden; box-shadow: 0 0 0 1.5px rgba(216,184,120,.4), 0 40px 90px rgba(0,0,0,.5); }
.pn { position: absolute; top: 0; bottom: 0; right: 0; width: 900px; padding: 80px 70px; direction: rtl; text-align: right; }
.pn small { display: block; font: 800 46px "Beiruti", sans-serif; letter-spacing: .02em; color: #8C9AB8; }
.pn h3 { margin: 14px 0 40px; font: 800 100px/1.1 "Beiruti", sans-serif; color: #F4EFE6; }
.pn p { margin: 0 0 26px; font: 700 62px/1.25 "Beiruti", sans-serif; word-spacing: .12em; color: #F4EFE6; display: flex; align-items: center; gap: 22px; }
.pn.b { background: linear-gradient(160deg, #18233A, #0D1528); }
.pn.b h3, .pn.b p { color: rgba(244,239,230,.5); }
.pn.a { background: radial-gradient(ellipse 80% 55% at 75% 15%, rgba(216,184,120,.24), transparent 70%), linear-gradient(160deg, #1D3056, #0F1B33); }
.pn.a small { color: #D8B878; }
.pn.a p i { flex: none; width: 60px; height: 60px; border-radius: 50%; background: #D8B878; color: #0F1B33; font: 800 36px/60px "Bricolage Grotesque", sans-serif; font-style: normal; text-align: center; }
#clip { position: absolute; top: 0; bottom: 0; right: 0; width: 900px; overflow: hidden; clip-path: inset(0% 0% 0% 100%); }
#line { position: absolute; top: 0; bottom: 0; left: 0; width: 8px; margin-left: -4px; background: #D8B878; box-shadow: 0 0 22px rgba(216,184,120,.8); }
#knob { position: absolute; top: 310px; left: -48px; width: 100px; height: 100px; border-radius: 50%; background: #D8B878; color: #0F1B33; font: 800 50px/100px "Bricolage Grotesque", sans-serif;
  text-align: center; box-shadow: 0 12px 30px rgba(0,0,0,.5); }
#cur { position: absolute; left: 0; top: 0; width: 70px; height: 70px; filter: drop-shadow(0 6px 10px rgba(0,0,0,.6)); }
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="5" data-width="1080" data-height="1920">
  <div id="bg" class="clip" data-start="0" data-duration="5" data-track-index="0"><div id="grid"></div></div>
  <div id="stage" class="clip" data-start="0" data-duration="5" data-track-index="1">
<div class="ttl" id="t1" style="top:320px;font-size:124px">{{TITLE}}</div>
    <div id="fr" data-layout-allow-overlap>
      <div class="pn b" data-layout-allow-overlap><small>{{BEFORE_LABEL}}</small><h3>{{BEFORE_HEAD}}</h3><p>{{BEFORE_LINE}}</p></div>
      <div id="clip" data-layout-allow-occlusion><div class="pn a"><small>{{AFTER_LABEL}}</small><h3>{{AFTER_HEAD}}</h3>
        <p><i>✓</i><span>{{AFTER_1}}</span></p><p><i>✓</i><span>{{AFTER_2}}</span></p><p><i>✓</i><span>{{AFTER_3}}</span></p></div></div>
      <div id="line"><b id="knob">⇆</b></div>
    </div>
    <svg id="cur" viewBox="0 0 24 24"><path d="M4 2l15 9-7 1.6L9 20z" fill="#F4EFE6" stroke="#0F1B33" stroke-width="1.4" stroke-linejoin="round" /></svg>
    <div class="handle">{{HANDLE}}</div>
  </div>
  <div id="grain" class="clip" data-start="0" data-duration="5" data-track-index="2"></div>
</div>
<script>
  var tl = gsap.timeline({ paused: true });
  // a line of text rises out of a soft blur
  function rise(sel, at) { tl.fromTo(sel, { y: 36, opacity: 0, filter: "blur(10px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.5, ease: "expo.out" }, at); }
  // the champagne block behind the key word wipes in from the right (Arabic reads right to left)
  function wipe(sel, at) { if (document.querySelector(sel)) tl.fromTo(sel, { "--wipe": "0%" }, { "--wipe": "100%", duration: 0.42, ease: "power2.inOut" }, at); }
var FX = 90, FY = 540, W = 900;
  var clipEl = document.getElementById("clip"), lineEl = document.getElementById("line");
  var st = { v: 100 };
  function place() { clipEl.style.clipPath = "inset(0% 0% 0% " + st.v + "%)"; var x = W * st.v / 100; gsap.set(lineEl, { x: x }); gsap.set("#cur", { x: FX + x - 8, y: FY + 370 }); }
  rise("#t1", 0);
  tl.fromTo("#fr", { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 0.5, ease: "expo.out" }, 0.05);
  tl.set(lineEl, { x: W }, 0);
  tl.fromTo("#cur", { x: 760, y: 1560, opacity: 0 }, { x: FX + W - 8, y: FY + 370, opacity: 1, duration: 0.3, ease: "power3.out" }, 0.12);
  tl.to("#knob", { scale: 0.86, duration: 0.08 }, 0.4);
  // the drag: the «after» panel wipes in from the right, the line and the cursor follow it
  tl.to(st, { v: 3, duration: 0.75, ease: "power2.inOut", onUpdate: place }, 0.45);
  tl.to("#knob", { scale: 1, duration: 0.15 }, 1.2);
  wipe(".pn.a .blk", 1.12); wipe("#t1 .blk", 1.15);
  tl.fromTo(".pn.a p i", { scale: 0, rotation: -30 }, { scale: 1, rotation: 0, duration: 0.35, ease: "back.out(2.6)", stagger: 0.08 }, 1.18);
  tl.to("#cur", { x: FX + W * 0.03 + 30, y: FY + 430, duration: 0.6, ease: "power2.inOut" }, 1.6);
  tl.fromTo(".pn.a small", { textShadow: "0 0 0 rgba(216,184,120,0)" }, { textShadow: "0 0 24px rgba(216,184,120,.9)", duration: 0.5, yoyo: true, repeat: 3, immediateRender: false }, 1.3);
  window.__timelines = window.__timelines || {};
  window.__timelines["main"] = tl;
</script>
</body>
</html>
```
