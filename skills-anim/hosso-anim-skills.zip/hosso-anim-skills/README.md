# HOSSO · 6 Animation Skills for Claude Code

ستة Skills لـ Claude Code. كل Skill أمر واحد بيعمل فيديو 9:16 (1080×1920، 5 ثواني) بهوية HOSSO: كحلي وشامبين، عربي بخط Beiruti وإنجليزي بـ Bricolage Grotesque. الفيديو بيترندر على جهازك بـ HyperFrames، ومن غير صوت.

| الأمر | بيعمل إيه |
| --- | --- |
| `/hosso-connect` | تطبيقين بيتوصلوا بخط ونبضة نور |
| `/hosso-counter` | رقم بيعدّ لحد هدفك ويخبط |
| `/hosso-terminal` | تيرمينال بيكتب أوامرك سطر سطر |
| `/hosso-room` | عنوانك جوه أوضة 3D كحلي |
| `/hosso-before-after` | سلايدر بيمسح القديم ويظهر الجديد |
| `/hosso-radial` | أيقونة في النص وحواليها كل حاجة |

## التركيب
1. انقل الستة فولدرات (`hosso-…`) لفولدر الـ skills بتاع Claude Code: `~/.claude/skills/` (ويندوز: `C:\Users\<اسمك>\.claude\skills\`). أو جوه مشروعك في `.claude/skills/`.
2. لازم يكون عندك Node.js 22 أو أحدث وFFmpeg، ونت أول مرة (npx بينزّل HyperFrames والمتصفح بتاعه).
3. افتح Claude Code واكتب مثلًا: `/hosso-connect وصّل Claude بـ Instagram · ريل كل يوم`

Claude بيعمل فولدر للفيديو، يملا القالب بكلامك، يشيّكه (`hyperframes check`) ويرندره، ويقولك مكان الـ MP4.

## English
Six Claude Code skills. Each one turns your words into a 9:16 HOSSO-style motion clip (navy + champagne, Beiruti + Bricolage Grotesque), rendered locally with HyperFrames. Copy the six `hosso-*` folders into `~/.claude/skills/`, then type e.g. `/hosso-counter 1,440 · دقيقة في اليوم`. Needs Node.js 22+ and FFmpeg.

Fonts: Beiruti and Bricolage Grotesque, SIL Open Font License 1.1 (see `fonts/FONTS-LICENSE.txt` in each skill).
By @hossovisuals.ai · hossovisuals.online
