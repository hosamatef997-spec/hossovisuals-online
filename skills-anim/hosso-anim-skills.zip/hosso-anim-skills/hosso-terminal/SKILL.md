---
name: hosso-terminal
description: Makes a 9:16 HOSSO-style video (HyperFrames, navy + champagne) of a terminal window where commands type themselves and the last line lands in champagne. Use when the user types /hosso-terminal or asks for a terminal / «تيرمينال بيكتب» animation.
---

# /hosso-terminal — تيرمينال بيكتب أوامرك سطر سطر

One prompt, one video: a 9:16 clip (1080×1920, 30 fps, 5 s) in the HOSSO look — navy `#0F1B33`, champagne `#D8B878`, ivory `#F4EFE6`, Arabic in **Beiruti**, Latin in **Bricolage Grotesque**.
What it shows: a glass terminal window rises, your two commands type themselves after the ❯ prompt (Arabic types right to left), the output lines appear, a progress bar fills and the last line lands in champagne.
It is rendered on the user's own computer with HyperFrames (HTML → MP4). Built on the HOSSO studio block «terminal».

Example: `/hosso-terminal claude · اعمل ريل النهارده · ✓ reel.mp4 جاهز`

## What you need from the user
The words after the command. Map them onto the fields below; anything they did not give keeps its default. If the main words are missing, ask once, in the user's language, then go on.

| Field | What goes there | Default |
| --- | --- | --- |
| `{{TITLE}}` | title above the window, with the ONE key word in the block | `<span>ريل</span> <span class="blk">بأمر واحد</span>` |
| `{{WIN_TITLE}}` | small title in the window bar | `claude — ~/reels` |
| `{{CMD1}}` | first command (English, typed left to right) | `claude` |
| `{{OUT1}}` | first output line | `Welcome to Claude Code` |
| `{{CMD2}}` | second command (Arabic, typed right to left) | `اعمل ريل النهارده` |
| `{{OUT2}}` | second output line (a progress bar follows it) | `Rendering… 30 fps` |
| `{{OK}}` | the result line, in champagne | `✓ reel.mp4 جاهز` |
| `{{HANDLE}}` | the user's handle at the bottom (or empty) | `@hossovisuals.ai` |

Text rules (they keep the look right):
- Put every Latin word or run (`Claude Code`, `reel.mp4`, `3D`) inside `<bdi class="lat">…</bdi>` when it sits in an Arabic line, so it keeps its order and gets Bricolage.
- Only ONE word (or two) per card goes in the champagne block: `<span class="blk">…</span>`. Keep the block where the template has it.
- In a line that holds the block, put the other words in their own `<span>…</span>` too (as in the defaults), or the contrast check reads the block as their background.
- Escape `<`, `>` and `&` in the user's words. Keep titles short (each title line ≤ 14 Arabic letters at this size) so nothing is cut.

## Do this
1. Make a folder `hosso-terminal-<short-slug>/` in the current directory.
2. Copy the three font files from this skill's `fonts/` folder (`beiruti-var-arabic.woff2`, `beiruti-var-latin.woff2`, `bricolage-grotesque-var-latin.woff2`) into `<folder>/assets/fonts/`, same names. If the user gave an image for an icon, copy it into `<folder>/assets/`.
3. Write `<folder>/index.html`: the template below, with every `{{…}}` replaced by the field value. Change nothing else.
4. Write `<folder>/hyperframes.json`: `{"$schema": "https://hyperframes.heygen.com/schema/hyperframes.json", "paths": {"blocks": "compositions", "components": "compositions/components", "assets": "assets"}, "media": {"autoProxy": true}}` and `<folder>/package.json`: `{"name": "hosso-terminal", "private": true, "type": "module"}`.
5. In the folder run `npx --yes hyperframes@0.8.221 check` and fix every error it reports, then `npx --yes hyperframes@0.8.221 render --output hosso-terminal.mp4`.
6. Look at one frame near the end (`ffmpeg -ss 3 -i hosso-terminal.mp4 -frames:v 1 check.jpg`): no word cut, nothing on top of something else. Then give the user the path of the MP4.

Keep the colours, fonts and timing as they are unless the user asks. The video has no sound; add music in your editor.
Needs: Node.js 22+, FFmpeg, and internet on the first run (npx downloads HyperFrames and its browser; the template loads GSAP from jsDelivr).

## Template (`index.html`)
```html
<!doctype html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1080, height=1920" />
<title>hosso-terminal</title>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js" integrity="sha384-sG0Hv1tP1lZCk9KQmrIbY/XNwi+OY84GQqhMscbnsoBFqAz8KNCil1kvfL3Hbbk2" crossorigin="anonymous"></script>
<style>
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-arabic.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0600-06FF, U+0750-077F, U+0870-08FF, U+200C-200E, U+2010-2011, U+FB50-FDFF, U+FE70-FEFC; }
@font-face { font-family: "Beiruti"; src: url("assets/fonts/beiruti-var-latin.woff2") format("woff2"); font-weight: 200 900; unicode-range: U+0000-00FF, U+2000-206F, U+20AC, U+2122, U+2212; }
@font-face { font-family: "Bricolage Grotesque"; src: url("assets/fonts/bricolage-grotesque-var-latin.woff2") format("woff2"); font-weight: 200 800; unicode-range: U+0000-00FF, U+2000-206F, U+2190-21FF, U+2212; }
:root { --navy: #0F1B33; --deep: #08101F; --slate: #5A6E93; --champ: #D8B878; --ivory: #F4EFE6; }
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 1080px; height: 1920px; overflow: hidden; background: #08101F; }
#root { position: relative; width: 1080px; height: 1920px; overflow: hidden; font-family: "Beiruti", sans-serif; color: #F4EFE6; }
#bg { position: absolute; inset: 0; background: radial-gradient(ellipse 70% 40% at 50% 42%, rgba(90,110,147,.42), transparent 72%), linear-gradient(170deg, #142544 0%, #0F1B33 55%, #08101F 100%); }
#grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(244,239,230,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(244,239,230,.04) 1px, transparent 1px);
  background-size: 67.5px 67.5px; -webkit-mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); mask-image: radial-gradient(ellipse 80% 55% at 50% 45%, #000 30%, transparent 85%); }
#stage { position: absolute; inset: 0; }
.lat { font-family: "Bricolage Grotesque", sans-serif; font-weight: 700; letter-spacing: -.01em; unicode-bidi: isolate; }
.ttl { position: absolute; left: 80px; right: 80px; text-align: center; direction: rtl; font-weight: 800; line-height: 1.12; color: #F4EFE6; text-shadow: 0 6px 30px rgba(4,9,20,.4); }
.blk { position: relative; display: inline-block; color: #0F1B33; background-color: #D8B878; border-radius: .2em; padding: .03em .2em .08em; margin: 0 .04em; line-height: 1.02; --wipe: 100%; text-shadow: none;
  clip-path: inset(0 0 0 calc(100% - var(--wipe)) round .2em); }
.handle { position: absolute; left: 0; right: 0; top: 1500px; text-align: center; font: 600 30px "Bricolage Grotesque", sans-serif; letter-spacing: .14em; color: rgba(244,239,230,.5); direction: ltr; }
#grain { position: absolute; inset: 0; opacity: .05; pointer-events: none; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>"); }
#win { position: absolute; left: 70px; width: 940px; top: 560px; height: 700px; border-radius: 32px; overflow: hidden; direction: ltr;
  background: linear-gradient(180deg, rgba(8,16,31,.94), rgba(15,27,51,.94)); box-shadow: 0 0 0 1.5px rgba(216,184,120,.5), 0 40px 90px rgba(0,0,0,.5); }
#wbar { position: absolute; left: 0; right: 0; top: 0; height: 76px; background: rgba(244,239,230,.05); border-bottom: 1px solid rgba(244,239,230,.08); }
#wbar i { position: absolute; top: 28px; width: 20px; height: 20px; border-radius: 50%; background: rgba(244,239,230,.25); }
#wbar span { position: absolute; left: 0; right: 0; top: 20px; text-align: center; font: 600 28px "Bricolage Grotesque", sans-serif; color: rgba(244,239,230,.6); }
.ln { position: absolute; left: 44px; right: 44px; height: 70px; display: flex; align-items: center; gap: 20px; font: 600 44px "Bricolage Grotesque", sans-serif; color: #F4EFE6; white-space: nowrap; opacity: 0; }
.pr { color: #D8B878; font-weight: 800; }
.ty { display: inline-block; white-space: nowrap; }
.ty.ar { direction: rtl; unicode-bidi: isolate; font: 800 48px "Beiruti", sans-serif; }
.out { color: rgba(244,239,230,.62); }
.sp { color: #D97757; }
.ok { color: #D8B878; font-weight: 800; }
#prog { display: inline-block; width: 200px; height: 14px; border-radius: 7px; background: rgba(244,239,230,.12); overflow: hidden; }
#prog u { display: block; width: 100%; height: 100%; background: #D8B878; transform-origin: left center; }
#caret { display: inline-block; width: 24px; height: 48px; background: #D8B878; border-radius: 3px; }
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="5" data-width="1080" data-height="1920">
  <div id="bg" class="clip" data-start="0" data-duration="5" data-track-index="0"><div id="grid"></div></div>
  <div id="stage" class="clip" data-start="0" data-duration="5" data-track-index="1">
<div class="ttl" id="t1" style="top:320px;font-size:120px">{{TITLE}}</div>
    <div id="win">
      <div id="wbar"><i style="left:30px;background:#D8B878"></i><i style="left:62px"></i><i style="left:94px"></i><span>{{WIN_TITLE}}</span></div>
      <div class="ln" id="l0" style="top:110px"><b class="pr">❯</b><span class="ty">{{CMD1}}</span></div>
      <div class="ln out" id="l1" style="top:202px"><b class="sp">✻</b><span>{{OUT1}}</span></div>
      <div class="ln" id="l2" style="top:294px"><b class="pr">❯</b><span class="ty ar">{{CMD2}}</span></div>
      <div class="ln out" id="l3" style="top:386px"><span>{{OUT2}}</span><em id="prog"><u></u></em></div>
      <div class="ln ok" id="l4" style="top:478px"><span>{{OK}}</span></div>
      <div class="ln" id="l5" style="top:570px"><b class="pr">❯</b><span id="caret"></span></div>
    </div>
    <div class="handle">{{HANDLE}}</div>
  </div>
  <div id="grain" class="clip" data-start="0" data-duration="5" data-track-index="2"></div>
</div>
<script>
  var tl = gsap.timeline({ paused: true });
  // a line of text rises out of a soft blur
  function rise(sel, at) { tl.fromTo(sel, { y: 36, opacity: 0, filter: "blur(10px)" }, { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.5, ease: "expo.out" }, at); }
  // the champagne block behind the key word wipes in from the right (Arabic reads right to left)
  function wipe(sel, at) { if (document.querySelector(sel)) tl.fromTo(sel, { "--wipe": "0%" }, { "--wipe": "100%", duration: 0.42, ease: "power2.inOut" }, at); }
rise("#t1", 0);
  tl.fromTo("#win", { y: 60, opacity: 0, scale: 0.96 }, { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: "expo.out" }, 0.05);
  function show(sel, at) { tl.fromTo(sel, { opacity: 0, x: -16 }, { opacity: 1, x: 0, duration: 0.2, ease: "power2.out" }, at); }
  // a command types itself letter by letter: English from the left, Arabic from the right
  function type(sel, at, dur) {
    tl.set(sel, { opacity: 1 }, at);
    var el = document.querySelector(sel + " .ty"), n = Math.max(1, el.textContent.length), ar = el.classList.contains("ar");
    tl.fromTo(el, { clipPath: ar ? "inset(0% 0% 0% 100%)" : "inset(0% 100% 0% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: dur, ease: "steps(" + n + ")" }, at);
  }
  type("#l0", 0.15, 0.25);
  show("#l1", 0.45);
  type("#l2", 0.55, 0.38);
  show("#l3", 0.98);
  tl.fromTo("#prog u", { scaleX: 0 }, { scaleX: 1, duration: 0.22, ease: "power1.inOut" }, 1.0);
  tl.fromTo("#l4", { opacity: 0, x: -24 }, { opacity: 1, x: 0, duration: 0.25, ease: "power3.out" }, 1.22);
  tl.fromTo("#l4", { textShadow: "0 0 0 rgba(216,184,120,0)" }, { textShadow: "0 0 26px rgba(216,184,120,.85)", duration: 0.25, yoyo: true, repeat: 1, immediateRender: false }, 1.25);
  wipe("#t1 .blk", 1.2);
  show("#l5", 1.45);
  tl.to("#caret", { opacity: 0, duration: 0.01, yoyo: true, repeat: 7, repeatDelay: 0.42 }, 1.9);
  window.__timelines = window.__timelines || {};
  window.__timelines["main"] = tl;
</script>
</body>
</html>
```
